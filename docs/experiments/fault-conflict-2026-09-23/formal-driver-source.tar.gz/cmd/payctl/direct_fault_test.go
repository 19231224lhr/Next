package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestFaultGateBlocksBeforeForwardAndNeverReleasesBlockedRequest(t *testing.T) {
	var calls atomic.Int32
	backend := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1); w.Write([]byte("ok")) }))
	defer backend.Close()
	gate := newFaultGate([]string{backend.URL})
	control := httptest.NewRecorder()
	gate.ServeHTTP(control, httptest.NewRequest("POST", "/control", strings.NewReader(`{"Block":["0/v3/certificates"]}`)))
	if control.Code != 200 {
		t.Fatal(control.Code)
	}
	out := httptest.NewRecorder()
	gate.ServeHTTP(out, httptest.NewRequest("POST", "/0/v3/certificates", nil))
	if out.Code != 503 || calls.Load() != 0 {
		t.Fatal("gate forwarded blocked request")
	}
	gate.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("POST", "/control", strings.NewReader(`{}`)))
	if calls.Load() != 0 {
		t.Fatal("unblocking released an old request")
	}
	out = httptest.NewRecorder()
	gate.ServeHTTP(out, httptest.NewRequest("POST", "/0/v3/certificates", nil))
	if out.Code != 200 || calls.Load() != 1 {
		t.Fatal("new request not forwarded")
	}
}

func TestFaultGateDelayCancellation(t *testing.T) {
	backend := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.Write([]byte("ok")) }))
	defer backend.Close()
	gate := newFaultGate([]string{backend.URL})
	gate.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("POST", "/control", strings.NewReader(`{"DelayMS":{"0/v3/transactions":1000}}`)))
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Millisecond)
	defer cancel()
	started := time.Now()
	gate.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("POST", "/0/v3/transactions", nil).WithContext(ctx))
	if time.Since(started) > 300*time.Millisecond {
		t.Fatal("delay ignored cancellation")
	}
}
