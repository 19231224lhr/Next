#!/usr/bin/env python3
"""Fresh independent native bench-v4 receipts, concurrency1, no pacing.

Reuses the older run_next lifecycle without modifying that shared runner. Only
its initialization command, gateway launch path and result reduction are scoped
to this invocation. No Go/build changes. Final C3 currently supports baseFee0:
the frozen bench-v4 builder emits its entire input as principal and cannot fund
a positive additional CAL quote. Unsupported positive quotes fail before boot.

taskset -c 0-3 python3 run_independent.py --bin BIN --run-dir NEW
 --variant final --count 100 --storage memory --gateway-mode compact
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
import pathlib
import shlex
import signal
import subprocess
import sys

from metrics import distribution

HERE=pathlib.Path(__file__).resolve().parent


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def positive(value):
    return type(value) in (int,float) and math.isfinite(value) and value>0


def independent_result(report,count):
    """FastMS/BlockObservedMS/MemberAppliedMS are native time.Since(sent).

    UnixNano diagnostics cannot provide send rate or receipt goodput when the
    wall clock steps. No monotonic absolute send offsets are exported by this
    frozen bench, so those derived rates are deliberately left unavailable.
    """
    summary=report.get('Summary') or {}
    rows=report.get('Samples') or []
    if summary.get('count')!=count or len(rows)!=count or summary.get('concurrency')!=1 or summary.get('same_org') is not True:
        raise ValueError('incomplete or non-comparable independent native benchmark')
    samples,facts,closure,jumps=[],set(),[],[]
    for i,row in enumerate(rows):
        elapsed=row.get('FastMS')
        sent,ready=row.get('SentUnixNS'),row.get('FastUnixNS')
        if row.get('Index')!=i or not positive(elapsed) or type(sent) is not int or type(ready) is not int or sent<=0 or ready<=0:
            raise ValueError(f'sample {i} lacks a native verified monotonic receiver receipt')
        fact=row.get('Fact')
        if not isinstance(fact,str) or len(fact)!=64 or any(c not in '0123456789abcdefABCDEF' for c in fact) or int(fact,16)==0 or fact in facts:
            raise ValueError(f'sample {i} has an invalid/repeated fact')
        facts.add(fact)
        def segment(name,instant,duration):
            if type(instant) is not int or instant<=0 or not positive(duration):
                raise ValueError(f'sample {i} lacks {name} observation evidence')
            wall=(instant-sent)/1e6
            if abs(wall-duration)>1:
                jumps.append(dict(index=i,segment=name,wall_start_ns=sent,wall_end_ns=instant,
                                  wall_elapsed_ms=wall,monotonic_elapsed_ms=duration))
        segment('receipt',ready,elapsed)
        if row.get('Outcome')!='COMPLETE' or row.get('Error'):
            closure.append(dict(index=i,error=row.get('Error') or row.get('Outcome') or 'unknown'))
        else:
            public,closed=row.get('BlockObservedMS'),row.get('MemberAppliedMS')
            if not positive(public) or not positive(closed) or public<elapsed or closed<public:
                raise ValueError(f'sample {i} lacks ordered monotonic public/member closure')
            segment('public',row.get('BlockObservedUnixNS'),public)
            segment('closed',row.get('MemberObservedUnixNS'),closed)
        if i and sent<rows[i-1]['SentUnixNS']:
            jumps.append(dict(index=i,segment='successive-send-wall-regression',
                              previous_wall_ns=rows[i-1]['SentUnixNS'],wall_ns=sent))
        samples.append(elapsed)
    if not positive(summary.get('elapsed_s')):
        raise ValueError('native whole-run monotonic duration absent')
    if not closure and summary.get('failed',0)!=0:
        raise ValueError('native failure count contradicts complete samples')
    return dict(samples_ms=samples,completed=count,receipt_status='complete',
                closure_status='incomplete' if closure else 'complete',closure_errors=closure,
                timing_source='native Go time.Since(sent) durations; no wall-clock latency subtraction',
                wall_clock_discontinuities=jumps,realized_send_rate_per_s=None,receipt_goodput_per_s=None,
                derived_rate_note='frozen bench exports no monotonic absolute send offsets; wall-derived rates omitted',
                native_closed_elapsed_s=summary['elapsed_s'],
                closed_run_completion_per_s=(count-len(closure))/summary['elapsed_s'])


def initialization(command,variant,base_fee):
    result=list(command)
    if 'init-lab' in result:
        if base_fee!=0:
            raise ValueError('frozen bench-v4 cannot fund a positive additional CAL quote; use base-fee0')
        result[result.index('--v4')]={'baseline':'--v4','noc3':'--v4','legacy':'--c3','final':'--c3-final'}[variant]
        if variant=='final':
            result.extend(('--c3-base-fee',str(base_fee)))
    return result


def run(args):
    if sys.platform!='linux':
        raise RuntimeError('run on Linux ext4, taskset -c 0-3')
    if not os.sched_getaffinity(0)<={0,1,2,3}:
        raise ValueError('inherit CPU affinity0-3 with taskset')
    if args.base_fee!=0:
        raise ValueError('frozen bench-v4 only supports final base-fee0; no builder changes are made')
    spec=importlib.util.spec_from_file_location('independent_base',HERE.parent/'baseline-design-2026-10-13'/'run_next.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
    binary_hashes={name:hashlib.sha256((args.bin/name).read_bytes()).hexdigest() for name in ('payctl','member','gateway','committee')}
    script_hash=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
    base_hash=hashlib.sha256((HERE.parent/'baseline-design-2026-10-13'/'run_next.py').read_bytes()).hexdigest()
    previous_command,previous_reduce,previous_popen=base.run_command,base.independent_result,subprocess.Popen
    previous_env={key:os.environ.get(key) for key in ('GOMAXPROCS','NO_PROXY','no_proxy','UTXO_EXPERIMENT_BUDGET','UTXO_EXPERIMENT_DISABLE_SOURCE_RECOVERY','UTXO_SETTLEMENT_TRACE')}
    os.environ.update(GOMAXPROCS='1',NO_PROXY='127.0.0.1,localhost',no_proxy='127.0.0.1,localhost')
    for key in ('UTXO_EXPERIMENT_BUDGET','UTXO_EXPERIMENT_DISABLE_SOURCE_RECOVERY','UTXO_SETTLEMENT_TRACE'):
        os.environ.pop(key,None)
    def command(argv,*rest,**kwargs):
        return previous_command(initialization(argv,args.variant,args.base_fee),*rest,**kwargs)
    def popen(argv,*rest,**kwargs):
        words=list(map(str,argv))
        if 'lab-run' in words and args.gateway_mode=='compact':
            binary=args.bin.resolve();launch=args.run_dir.resolve()/'independent-launch-bin';launch.mkdir()
            for name in ('payctl','member','committee'):
                (launch/name).symlink_to(binary/name)
            gateway=launch/'gateway'
            gateway.write_text('#!/bin/sh\nexec '+shlex.quote(str(binary/'gateway'))+' --compact-direct-approvals "$@"\n')
            gateway.chmod(0o755)
            words[words.index('--bin')+1]=str(launch)
        return previous_popen(words,*rest,**kwargs)
    base.run_command,base.independent_result,subprocess.Popen=command,independent_result,popen
    args.workload,args.rate,args.length='independent',0,1
    metadata=dict(variant=args.variant,base_fee=args.base_fee,gateway_mode=args.gateway_mode,
        count=args.count,concurrency=1,target_rate=0,cpu_affinity=sorted(os.sched_getaffinity(0)),
        gomaxprocs='1',harness_sha256=script_hash,reused_runner_sha256=base_hash,binary_sha256=binary_hashes)
    try:
        result=base.run(args)
        result.update(distribution(result['samples_ms'],'receipt_ms'))
        result.update(variant=args.variant,gateway_mode=args.gateway_mode,concurrency=1)
        write(args.run_dir/'independent-result.json',result)
        return result
    except BaseException as exc:
        metadata['error']=repr(exc)
        raise
    finally:
        base.run_command,base.independent_result,subprocess.Popen=previous_command,previous_reduce,previous_popen
        for key,value in previous_env.items():
            if value is None:os.environ.pop(key,None)
            else:os.environ[key]=value
        if args.run_dir.is_dir():
            network=args.run_dir/'config'/'network.json'
            if network.is_file():
                metadata['actual_network']=json.loads(network.read_text())
                metadata['actual_network_sha256']=hashlib.sha256(network.read_bytes()).hexdigest()
            write(args.run_dir/'independent-manifest.json',metadata)


def self_test():
    import copy
    report=dict(Summary=dict(count=2,concurrency=1,same_org=True,elapsed_s=.1,failed=0),Samples=[])
    for i in range(2):
        report['Samples'].append(dict(Index=i,Fact=str(i+1)*64,SentUnixNS=10_000_000,
            FastUnixNS=9_000_000,FastMS=2,BlockObservedUnixNS=14_000_000,BlockObservedMS=4,
            MemberObservedUnixNS=16_000_000,MemberAppliedMS=6,Outcome='COMPLETE'))
    result=independent_result(report,2)
    assert result['closure_status']=='complete' and len(result['wall_clock_discontinuities'])==2
    assert result['receipt_goodput_per_s'] is None
    broken=copy.deepcopy(report);broken['Samples'][1]['Fact']=broken['Samples'][0]['Fact']
    try:independent_result(broken,2)
    except ValueError:pass
    else:raise AssertionError('duplicate fact accepted')
    broken=copy.deepcopy(report);broken['Samples'][1]['MemberAppliedMS']=0
    try:independent_result(broken,2)
    except ValueError:pass
    else:raise AssertionError('missing closure accepted')
    argv=['payctl','init-lab','--v4','--dir','fresh']
    for variant,flag in [('baseline','--v4'),('legacy','--c3'),('final','--c3-final')]:
        changed=initialization(argv,variant,0)
        assert flag in changed and argv==['payctl','init-lab','--v4','--dir','fresh']
    return dict(adapter='passed',init_variants='passed',services_started=False)


def main():
    if sys.argv[1:]==['--self-test']:
        print(json.dumps(self_test()));return
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bin',type=pathlib.Path,required=True)
    parser.add_argument('--run-dir',type=pathlib.Path,required=True)
    parser.add_argument('--variant',type=str.lower,choices=('baseline','noc3','legacy','final'),required=True)
    parser.add_argument('--count',type=int,default=100)
    parser.add_argument('--base-fee',type=int,default=0)
    parser.add_argument('--gateway-mode',choices=('plain','compact'),default='compact')
    parser.add_argument('--storage',choices=('memory','sync'),default='memory')
    args=parser.parse_args()
    def interrupted(signum,_frame):
        raise InterruptedError(f'independent runner interrupted: {signum}')
    signal.signal(signal.SIGTERM,interrupted)
    result=run(args)
    print(json.dumps(result))
    if result.get('native_exit_code',0):raise SystemExit(result['native_exit_code'])


if __name__=='__main__':
    main()
