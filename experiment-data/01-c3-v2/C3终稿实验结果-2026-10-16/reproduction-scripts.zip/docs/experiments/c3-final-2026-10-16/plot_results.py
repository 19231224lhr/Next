"""Publication-sized figures from measured CSV only; run analyze.py first."""
import argparse,collections,csv,json,pathlib,statistics,sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--audit-dir',type=pathlib.Path,required=True);a=p.parse_args()
sys.path.insert(0,str(a.audit_dir));from audit_panel_alignment import require_matplotlib_panel_alignment
a.out.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.labelsize':8,'axes.titlesize':8,'legend.fontsize':7,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.right':False,'axes.spines.top':False,'axes.linewidth':.7,'legend.frameon':False})
def csvread(name):
    path=a.data/name
    return list(csv.DictReader(path.open(encoding='utf-8-sig'))) if path.exists() else []
def num(row,key):return float(row[key])
def ok(row):return row.get('data_valid')!='False'
def form(n=2,height=2.65):
    fig,axes=plt.subplots(1,n,figsize=(7.1 if n>1 else 3.5,height),squeeze=False)
    fig.subplots_adjust(left=.085 if n>1 else .17,right=.985,bottom=.24,top=.84,wspace=.38)
    for i,ax in enumerate(axes[0]):
        ax.set_title(chr(97+i),loc='left',fontweight='bold')
        ax.use_sticky_edges=False
        ax.margins(y=.08)
    return fig,axes[0]
def save(fig,name):
    for ax in fig.axes:
        ax.get_ylim()  # Resolve pending autoscaling before fixing the zero baseline.
        ax.set_ylim(bottom=0)
        assert ax.get_ylim()[1]+1e-10>=ax.dataLim.y1, (name, ax.get_ylim(), tuple(ax.dataLim.bounds))
    fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=a.out/(name+'.alignment.json'))
    fig.savefig(a.out/(name+'.pdf'))
    fig.savefig(a.out/(name+'.svg'))
    fig.savefig(a.out/(name+'.png'),dpi=300)
    plt.close(fig)
def points(ax,groups,labels,colors,scale=1):
    for i,(values,color) in enumerate(zip(groups,colors)):
        v=np.array(values,dtype=float)/scale
        if not len(v):raise ValueError('missing complete measured group: '+labels[i])
        ax.plot([i,i],[min(v),max(v)],color=color,lw=1.3)
        offsets=np.linspace(-.10,.10,len(v))
        ax.scatter(i+offsets,v,s=12,marker='o',facecolors='white',edgecolors=color,linewidths=.8,zorder=3)
        ax.plot([i-.15,i+.15],[statistics.median(v)]*2,color=color,lw=2,zorder=4)
    ax.set_xticks(range(len(labels)),labels);ax.set_xlim(-.5,len(labels)-.5)
colors=['#777777','#B7A78E','#286DA8','#96779A','#A85650']
runs=csvread('runs.csv');fees=csvread('fees.csv');con=csvread('congestion-payments.csv')
methods=['baseline','legacy','final','fastpay-official','fastpay-tuned'];labels=['Next\nNo C3','Next\nC3 v1','Next\nC3 v2','FastPay\nOfficial','FastPay\nTuned']
if all(any(r['suite']=='formal-chain'+str(n) and r['arm']==m and ok(r) for r in runs) for n in (100,1000) for m in methods):
    fig,axes=form()
    for ax,n in zip(axes,[100,1000]):
        values=[[num(r,'chain_total_ms') for r in runs if r['suite']=='formal-chain'+str(n) and r['arm']==m and ok(r)] for m in methods]
        points(ax,values,labels,colors,1000);ax.set_ylabel('Last verified receipt (s)');ax.set_xlabel(f'{n} dependent payments; 7 runs per method')
    save(fig,'A-continuous-payments')
orders=['source-first','child-first','compensated'];orderlabels=['Source\nfirst','Successor\nfirst','Compensation\nthen recovery']
if all(any(f['suite']=='formal-orders' and f['case']==case for f in fees) for case in orders):
    fig,axes=form()
    groups=[[num(f,'source_quote_cal')+num(f,'child_quote_cal') for f in fees if f['suite']=='formal-orders' and f['case']==case] for case in orders]
    points(axes[0],groups,orderlabels,[colors[2]]*3);axes[0].set_ylabel('User service fees per pair (CAL)');axes[0].set_ylim(0,5);axes[0].set_xlabel('5 runs per order; user FUEL expenditure = 0')
    rewards=[];reflow=[]
    for case in orders:
        fs=[f for f in fees if f['suite']=='formal-orders' and f['case']==case]
        assert len({(f['rewards'],f['reflow']) for f in fs})==1,'show variation explicitly if fee accounting varies'
        rewards.append(num(fs[0],'rewards'));reflow.append(num(fs[0],'reflow'))
    axes[1].bar(np.arange(3),rewards,.55,color=colors[2],label='Fixed committee rewards',edgecolor=colors[2])
    axes[1].bar(np.arange(3),reflow,.55,bottom=rewards,color='white',label='Timeout redistribution',edgecolor='#A86F18',linewidth=1)
    axes[1].set_xticks(range(3),orderlabels);axes[1].set_ylabel('Issuer expenditure per pair (FUEL)');axes[1].set_ylim(0,12);axes[1].set_xlabel('Identical accounting in all 5 runs per order')
    fig.legend(*axes[1].get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.54,1),ncol=2)
    save(fig,'C-fee-assurance')
delays=sorted({num(f,'delay_ms') for f in fees if f['suite']=='formal-delays'})
if len(delays)==4:
    fig,axes=form();normal=[];recovered=[];times=[]
    for delay in delays:
        fs=[f for f in fees if f['suite']=='formal-delays' and num(f,'delay_ms')==delay];by=collections.defaultdict(list)
        for f in fs:by[f['run']].append(f)
        normal.append([sum(x['recovered']=='False' for x in v) for v in by.values()]);recovered.append([sum(x['recovered']=='True' for x in v) for v in by.values()]);times.append([statistics.median(num(x,'closed_ms') for x in v) for v in by.values()])
    x=np.arange(len(delays));means=[statistics.mean(v) for v in normal];recmeans=[statistics.mean(v) for v in recovered]
    axes[0].bar(x,means,.55,color=colors[2],label='Normal fulfillment',edgecolor=colors[2]);axes[0].bar(x,recmeans,.55,bottom=means,color='white',label='Compensated and recovered',edgecolor='#A86F18',linewidth=1)
    for i,v in enumerate(normal):
        axes[0].scatter(i+np.linspace(-.12,.12,len(v)),v,s=12,facecolors='white',edgecolors='black',linewidths=.7,zorder=4,clip_on=False)
    axes[0].set_ylabel('Completed pairs per run');axes[0].set_xticks(x,[str(int(d)) for d in delays]);axes[0].set_xlabel('Requested source delay (ms); bars = means')
    points(axes[1],times,[str(int(d)) for d in delays],[colors[2]]*len(delays),1000);axes[1].set_ylabel('Median pair closure offset (s)');axes[1].set_xlabel('Requested source delay (ms); 5 runs')
    fig.legend(*axes[0].get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.54,1),ncol=2)
    save(fig,'B-source-resolution')
if con:
    fig,axes=form();classes=['ordinary-base','ordinary-priority','source-recovery'];classlabels=['Base\npayments','Priority\npayments','Source\nrecovery']
    for ax,bps in zip(axes,[1,2500]):
        groups=[]
        for cls in classes:
            by=collections.defaultdict(list)
            for c in con:
                if c['reserved_bps']==str(bps) and c['traffic_class']==cls:by[c['run']].append(num(c,'submit_to_block_ms'))
            groups.append([statistics.median(v) for v in by.values()])
        points(ax,groups,classlabels,[colors[0],colors[2],'#B68C40'],1000);ax.set_ylabel('Median submit-to-block wait (s)');ax.set_xlabel(f'Reserved bytes = {bps/100:g}%; 5 runs')
    save(fig,'D-priority-and-reserved-processing')
rtt=[r for r in runs if r['suite']=='formal-rtt' and ok(r)]
if rtt:
    fig,axes=form(1);ax=axes[0]
    for method,color,marker in [('final',colors[2],'o'),('fastpay-official',colors[3],'s'),('fastpay-tuned',colors[4],'^')]:
        ds=sorted({num(r,'rtt_ms') for r in rtt if r['arm']==method});vals=[[num(r,'chain_total_ms')/1000 for r in rtt if r['arm']==method and num(r,'rtt_ms')==d] for d in ds]
        med=np.array([statistics.median(v) for v in vals]);low=np.array([min(v) for v in vals]);high=np.array([max(v) for v in vals]);ax.errorbar(ds,med,yerr=[med-low,high-med],color=color,marker=marker,capsize=2,label={'final':'Next C3 v2','fastpay-official':'FastPay Official','fastpay-tuned':'FastPay Tuned'}[method])
    ax.set_xlabel('Configured proxy RTT per link (ms)');ax.set_ylabel('100-payment last receipt (s)');ax.legend(loc='upper left');save(fig,'S-controlled-rtt')
(a.out/'plot-source.json').write_text(json.dumps(dict(data=str(a.data),script=str(pathlib.Path(__file__).resolve()),replication_unit='fresh service run',summary='median and full range; individual points where shown',excluded='pilot runs; incomplete or invalid timing groups remain in analysis CSV'),indent=2)+'\n')
