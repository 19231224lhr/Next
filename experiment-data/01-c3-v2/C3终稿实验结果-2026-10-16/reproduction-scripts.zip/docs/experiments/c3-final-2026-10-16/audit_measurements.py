"""Check completeness and accounting in the final measured data, without reruns."""
import argparse,collections,csv,json,pathlib,statistics
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,required=True);p.add_argument('--data',type=pathlib.Path,required=True);a=p.parse_args()
def rows(name):return list(csv.DictReader((a.data/(name+'.csv')).open(encoding='utf-8-sig')))
runs=rows('runs');fees=rows('fees');congestion=rows('congestion-payments')
expected={'formal-orders':15,'formal-switches':15,'formal-chain100':35,'formal-chain1000':35,'formal-mixed':15,'formal-delays':20,'formal-congestion':10,'formal-independent':15,'formal-rtt':45,'formal-capacity-faults':25,'diagnostic-preparation':3}
counts=dict(collections.Counter(r['suite'] for r in runs));assert counts==expected,(counts,expected)
assert all(r.get('data_valid')!='False' and not r.get('analysis_error') for r in runs)
assert len(fees)==415
assert all(f['fuel_conserved']=='True' and float(f['held'])==0 and float(f['user_fuel'])==0 for f in fees)
assert all(float(f['source_receive_cal'])==98 and float(f['child_receive_cal'])==96 for f in fees)
assert all(float(f['source_quote_cal'])==2 and float(f['child_quote_cal'])==2 for f in fees)
assert all(float(f['rewards'])==8 and float(f['source_spent'])+float(f['child_spent'])==8+float(f['reflow']) for f in fees)
assert all(float(f['source_budget'])*2==float(f['source_spent'])+float(f['child_spent'])+float(f['released']) for f in fees)
for r in runs:
    if r['suite']=='formal-congestion':assert r['fuel_conserved']=='True' and not r.get('error')
    if r['suite']=='formal-mixed':assert r['attempted']==r['receipts']==r['closed']
capacity=[r for r in runs if r['suite']=='formal-capacity-faults']
assert all(r['final_pool_funding_identity']=='True' for r in capacity)
assert all(int(r['receipts_without_closure'])==0 for r in capacity)
assert all(int(r['final_fuel_held'])==0 for r in capacity)
for r in capacity:
    if not r.get('cal_capacity') and not r.get('fuel_capacity'):
        assert r['attempted']==r['receipts']==r['closed'] and int(r['returncode'])==0
faults=[]
for path in sorted((a.root/'formal-capacity-faults').glob('*/fault-events.jsonl')):
    ev=[json.loads(line) for line in path.read_text().splitlines()]
    stop=[e for e in ev if e['kind']=='stopped'];resume=[e for e in ev if e['kind']=='continued']
    if not stop:continue
    assert len(stop)==len(resume)==1
    before,after=stop[0],resume[0]
    assert (before['target']['pid'],before['target']['start_ticks'])==(after['target']['pid'],after['target']['start_ticks'])
    elapsed=(after['monotonic_ns']-before['monotonic_ns'])/1e9
    assert elapsed>=4.9
    faults.append(dict(run=path.parent.name,pause_seconds=elapsed,pid=before['target']['pid'],cpus=before['target']['cpus']))
assert len(faults)==10
result=dict(status='PASS',registered_runs=len(runs),counts=counts,fee_pairs_checked=len(fees),congestion_observations=len(congestion),original_nonzero_runs=[dict(suite=r['suite'],run=r['run'],returncode=r['returncode'],native_exit_code=r.get('native_exit_code'),attempted_without_receipt=r.get('attempted_without_receipt')) for r in runs if int(r['returncode'])],capacity_received_but_unclosed=0,capacity_pool_identities_checked=len(capacity),faults=faults,notes=['Expected incomplete unadmitted requests under limited capacity are retained, not marked successful.','Accounting and timing checks apply to measured executions and do not constitute general formal proofs.'])
(a.data/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('original_nonzero_runs','faults','notes')}))
