"""Freeze source and build Linux artifacts without touching the user's Git index."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DEST = ROOT/'.scratch/c3-final-frozen-2026-10-16'
BIN = ROOT/'.scratch/c3-final-bin'
if DEST.exists() or BIN.exists():
    raise FileExistsError('frozen artifacts already exist')
baseline = json.loads((HERE/'baseline-manifest.json').read_text())
tops = {p['path'].split('/')[0] for p in baseline['files'] if '/' in p['path']}
paths = [ROOT/'go.mod', ROOT/'go.sum']
for top in sorted(tops):
    paths += sorted((ROOT/top).rglob('*.go'))
    paths += sorted((ROOT/top).rglob('go.mod'))
    paths += sorted((ROOT/top).rglob('go.sum'))
    for testdata in (ROOT/top).rglob('testdata'):
        if testdata.is_dir():
            paths += [p for p in testdata.rglob('*') if p.is_file()]
rows = []
for path in paths:
    relative = path.relative_to(ROOT)
    target = DEST/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    rows.append({'path':relative.as_posix(),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size})
shutil.copytree(ROOT/'.scratch/c3-final-baseline-2026-10-16/.scratch/comet-src', DEST/'.scratch/comet-src')
manifest = {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'source_snapshot':str(DEST),'files':rows,'dependency_manifest':'baseline-dependency-manifest.json'}
(HERE/'final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
env = dict(os.environ,GOOS='linux',GOARCH='amd64',CGO_ENABLED='0')
BIN.mkdir()
for name in ['payctl','member','gateway','committee']:
    subprocess.run(['go','build','-tags=comet_v3','-trimpath','-o',str(BIN/name),'./cmd/'+name],cwd=DEST,env=env,check=True)
    info = subprocess.check_output(['go','version','-m',str(BIN/name)],cwd=DEST,text=True)
    (HERE/f'final-{name}-buildinfo.txt').write_text(info)
build = {'kind':'final-C3-v2','head':manifest['head'],'dirty_source_manifest':'final-manifest.json',
         'dependency_manifest':'baseline-dependency-manifest.json','build_flags':['-tags=comet_v3','-trimpath'],
         'environment':{k:env[k] for k in ['GOOS','GOARCH','CGO_ENABLED']},
         'go':subprocess.check_output(['go','version'],cwd=DEST,text=True).strip(),
         'binary_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in BIN.iterdir()}}
(HERE/'final-build.json').write_text(json.dumps(build,indent=2)+'\n')
print(json.dumps(build))
