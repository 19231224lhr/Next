"""Continue the predeclared campaign without replacing earlier observations."""
import json, pathlib, subprocess, sys, time
here=pathlib.Path(__file__).resolve().parent
root=pathlib.Path(sys.argv[1])
phases=json.loads((root/'campaign-plan.json').read_text())
phases[0]=['formal-switches-remaining', phases[0][1]+['--start-index','6']]
with (root/'resume-campaign-status.jsonl').open('x') as status:
    for name, extra in phases:
        command=[sys.executable,str(here/'run_matrix.py'),'--root',str(root/name),'--final-bin',str(root/'final-bin'),'--old-bin',str(root/'baseline-bin'),'--fixtures',str(root/'fixtures'),*extra]
        print('PHASE '+name,flush=True)
        with (root/(name+'-campaign.log')).open('x') as log:
            proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
            try: code=proc.wait()
            except BaseException:
                proc.terminate()
                try: proc.wait(timeout=55)
                except subprocess.TimeoutExpired: proc.kill();proc.wait()
                raise
        status.write(json.dumps(dict(phase=name,returncode=code,ended_ns=time.time_ns(),command=command))+'\n');status.flush()
        print('END '+name+' '+str(code),flush=True)
        if code: raise SystemExit(code)
