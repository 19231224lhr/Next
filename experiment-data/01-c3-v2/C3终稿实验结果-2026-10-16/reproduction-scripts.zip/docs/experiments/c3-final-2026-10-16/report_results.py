"""Write the Chinese report directly from run-level measured CSV."""
import collections,csv,pathlib,statistics
here=pathlib.Path(__file__).resolve().parent
def rows(name):
    p=here/'analysis'/name
    return list(csv.DictReader(p.open(encoding='utf-8-sig'))) if p.exists() else []
runs=rows('runs.csv');pairs=rows('paired.csv');fees=rows('fees.csv');con=rows('congestion-payments.csv')
labels={'baseline':'Next / No C3','legacy':'Next / C3 v1','final':'Next / C3 v2','fastpay-official':'FastPay 官方运行时','fastpay-tuned':'FastPay 单 worker'}
def val(v,k):return [float(x[k]) for x in v if x.get(k) not in (None,'')]
def stat(v,d=3):
    if not v:return '—'
    return f'{statistics.median(v):.{d}f} [{min(v):.{d}f}, {max(v):.{d}f}]'
def select(suite,arm=None):return [r for r in runs if r['suite']==suite and (arm is None or r['arm']==arm) and r.get('data_valid')!='False']
out=[]
def add(s=''):out.append(s)
def table(headers,data):
    add('| '+' | '.join(headers)+' |');add('| '+' | '.join(['---']*len(headers))+' |')
    for r in data:add('| '+' | '.join(map(str,r))+' |')
    add()
add('# Next 终稿 C3：真实服务实验结果')
add('\n本报告由 `report_results.py` 从逐轮 CSV 生成。中位数后的方括号为独立运行的最小值与最大值，单位随列标题注明；同一轮内的多笔付款不算独立重复。原始失败和不利结果均保留。\n')
add('## 1. 实验与版本')
add('\n终稿 C3 v2 已落地：用户只支付固定 CAL 服务费，签发组织保障 FUEL，正常乱序采用固定报酬，超时费用回流其他组织。C3 v1 是用户支付 FUEL、采用旧阶段费用的版本；No C3 是同一修改前源码关闭费用机制的配置。新旧版本分别冻结并记录二进制哈希。\n')
add('环境为 Ryzen AI 9 HX 370、WSL2 Ubuntu 24.04、4 个逻辑 CPU（CPU 0–3，客体拓扑显示为两核四线程）、每个 Go 进程 GOMAXPROCS=1。所有负载串行运行。服务使用内存存储；Next 钱包为 ext4/NoSync，FastPay 钱包为内存。性能负载使用零 CAL 基础报价，但 FUEL 预留和费用转换开启；非零报价由费用实验单独验证。\n')
table(['组别','有效原始运行数','用途'],[(s,len(select(s)),desc) for s,desc in [('formal-orders','三种执行顺序与费用'),('formal-switches','同语义配置开关'),('formal-chain100','100 笔依赖链'),('formal-chain1000','1000 笔依赖链'),('formal-mixed','固定负载与后台闭合'),('formal-delays','来源延迟与恢复'),('formal-congestion','优先服务与保留通道'),('formal-independent','独立付款认证'),('formal-rtt','受控 RTT 对照'),('formal-capacity-faults','有限额度与单节点暂停'),('diagnostic-preparation','准备阶段诊断')]])
add('源码通过全套带 `comet_v3` 标记的测试。安全证据、实现改动和复现入口分别见 `EVIDENCE.zh-CN.md`、`IMPLEMENTATION.zh-CN.md` 与 `REPRODUCE.md`。\n')
add('## 2. 费用确定性与资金清偿')
data=[]
for case in ['source-first','child-first','compensated']:
    v=[r for r in fees if r['suite']=='formal-orders' and r['case']==case]
    if not v:continue
    assert len({tuple(r[k] for k in ['source_quote_cal','child_quote_cal','source_spent','child_spent','rewards','reflow','released','held','user_fuel']) for r in v})==1
    r=v[0];data.append([case,len(v),float(r['source_quote_cal'])+float(r['child_quote_cal']),r['user_fuel'],r['source_spent'],r['child_spent'],r['rewards'],r['reflow'],r['released'],r['held']])
table(['顺序','轮次','用户 CAL 合计','用户 FUEL','来源支出 FUEL','后继支出 FUEL','委员会报酬 FUEL','回流 FUEL','释放 FUEL','最终冻结 FUEL'],data)
add('每对付款的来源输入为 100 CAL，签名输出为 98 CAL、服务费为 2 CAL；后继签名输出为 96 CAL、服务费为 2 CAL。收款到账等于签名约定的完整本金。两笔凭证各预留 6 FUEL。正常顺序和正常乱序的支出相同；赔付与迟到偿还使来源组织多承担 2 FUEL，委员会报酬不增加。实际纪元结算将该费用转给另一组织，费用守恒检查通过。\n')
table(['顺序','采样到的公共托管 Held 峰值 FUEL'],[(case,stat(val([r for r in select('formal-orders') if r.get('case')==case],'sampled_peak_public_held_fuel'),0)) for case in ['source-first','child-first','compensated']])
add('公共托管峰值来自定期快照，可能漏掉更短的峰值；它不是未公开承诺的总额。成员签名预留另见原始报告 `Samples.Members`，不能与公共 Held 直接相加。\n')
add('重复 HTTP 提交被拒且没有新增费用，只能证明这条拒绝路径未重复收费；执行层重复事件与替代签票集合的幂等性由代码测试覆盖。多组织取整余数、补资与重启也有集成测试，本轮两组织服务实验不冒充三组织部署验证。\n')
add('## 3. 认证与连续付款')
for n in [100,1000]:
    add(f'### {n} 笔依赖链\n')
    data=[]
    for arm in labels:
        v=select('formal-chain'+str(n),arm)
        if v:data.append([labels[arm],len(v),stat([x/1000 for x in val(v,'chain_total_ms')]),stat(val(v,'receipt_ms_p50')),stat(val(v,'receipt_ms_p95')),stat(val(v,'following_build_ms'))])
    table(['方案','轮次','末笔收据 s','每轮收据 P50 ms','每轮收据 P95 ms','第 2 至末笔准备合计 ms'],data)
    data=[]
    for arm in labels:
        v=[r for r in pairs if r['suite']=='formal-chain'+str(n) and r['control']==arm and r['metric']=='chain_total_ms']
        if v:data.append([labels[arm],stat(val(v,'reduction_percent'),2),str(sum(float(x['reduction_percent'])>0 for x in v))+'/'+str(len(v))])
    table(['C3 v2 相对方案','逐轮配对缩短比例 %','C3 v2 更快轮次'],data)
add('收据终点为收款钱包验证并可继续付款；链时间包含后续请求准备，不含第一笔准备。Next 的公开执行与成员闭合另列于 `analysis/runs.csv`。FastPay 使用 receiver-confirmed 客户端路径，不能把该路径包含的同步工作写成其证书形成需要多轮通信。\n')
data=[]
for arm in labels:
    v=select('formal-independent',arm)
    if v:data.append([labels[arm],len(v),stat(val(v,'receipt_ms_p50')),stat(val(v,'receipt_ms_p95'))])
if data:table(['独立付款方案','轮次（每轮 100 笔）','P50 ms','P95 ms'],data)
add('配置开关的逐轮结果见 `analysis/paired.csv`。紧凑传输和续付开关的收益并非每轮一致，因此没有把某个默认开关当成长链差距的唯一原因。请求准备的原生阶段诊断另外保存，不混入未开启诊断的性能结果。\n')
stages=rows('preparation-stages.csv');stagegroups=collections.defaultdict(lambda:collections.defaultdict(float))
for r in stages:
    if int(r['hop'])>1:stagegroups[(r['category'],r['stage'])][r['run']]+=float(r['duration_ms'])
if stagegroups:
    table(['诊断类别','阶段','第 2 至 1000 笔累计 ms'],[(c,s,stat(list(v.values()))) for (c,s),v in sorted(stagegroups.items())])
    add('BuildStagesMS 是连续、互斥的外层计时段；BuildSaveStagesMS 是 save_request 的内部拆分，不能再与外层合计相加。内部 update_total 包括 queue_wait、validation_and_locks、commit_and_resume。encode_before_update 是整个 save_request 减去存储事务时间，包含签名、编码等事务外处理，不能解释为纯序列化。诊断只开三轮，不用于正式速度比较。\n')
size=[]
for arm in ['baseline','legacy','final']:
    v=select('formal-chain1000',arm)
    if v:size.append([labels[arm],stat(val(v,'certificate_bytes_p50'),0)])
if size:table(['方案','凭证大小中位数 bytes'],size)
add('CPU、RSS、I/O 与 loopback 采样在 `resource-boundaries.csv`，包含整次初始化及运行。公共执行阶段另存同一委员会进程的局部诊断时间；其原始墙钟计时不能替代正式单调时间指标，也不能把重复记录的区块提交耗时逐笔累加。\n')
resource=rows('resource-boundaries.csv');data=[]
for arm in ['baseline','legacy','final']:
    v=[r for r in resource if r['suite']=='formal-chain1000' and r['arm']==arm]
    if v:data.append([labels[arm],stat(val(v,'cpu_seconds_sampled'),2),stat(val(v,'peak_tree_rss_mib'),1),stat([x/1048576 for x in val(v,'write_bytes_sampled')],1)])
if data:table(['1000 笔完整运行','采样进程树 CPU s','峰值 RSS MiB','采样写入 MiB'],data)
add('## 4. 固定负载、来源延迟与故障')
data=[]
for arm in ['baseline','legacy','final']:
    v=select('formal-mixed',arm)
    if v:data.append([labels[arm],len(v),stat(val(v,'attempted'),0),stat(val(v,'in_window_receipts'),0),stat(val(v,'in_window_public'),0),stat(val(v,'closed'),0),stat(val(v,'receipt_ms_p50')),stat(val(v,'closed_drain_seconds'))])
table(['方案','轮次','实际发送','窗口内收据','窗口内公开执行','排空后闭合','收据 P50 ms','后台排空 s'],data)
add('每轮计划 100 笔/s、持续 30 s，正式计划量 3,000 笔，预热另计。表中实际发送少于计划的部分属于调度或容量影响，未被补算成成功付款。完整 CSV 保留计划量、实际量、窗口内完成、排空后完成和未发送原因。本实验测量固定负载表现，不宣称最大 TPS。\n')
data=[]
for delay in sorted({float(r['delay_ms']) for r in fees if r['suite']=='formal-delays'}):
    v=[r for r in fees if r['suite']=='formal-delays' and float(r['delay_ms'])==delay];by=collections.defaultdict(list)
    for r in v:by[r['run']].append(r)
    data.append([int(delay),len(by),stat([len(x) for x in by.values()],0),stat([sum(r['recovered']=='True' for r in x) for x in by.values()],0),stat([sum(float(r['reflow']) for r in x) for x in by.values()],0),stat([statistics.median(float(r['closed_ms'])/1000 for r in x) for x in by.values()])])
if data:table(['请求来源延迟 ms','轮次','完成对数','赔付后恢复对数','超时回流合计 FUEL','每轮闭合偏移 P50 s'],data)
add('来源延迟是客户端请求的等待参数。公开执行顺序由实际共识决定，不能直接把延迟参数当作账本上缺源的持续时间。闭合偏移从该次负载公共起点计算，不等同单笔请求延迟。\n')
data=[]
v=select('formal-capacity-faults');by=collections.defaultdict(list)
for r in v:by[(r.get('cal_capacity') or '',r.get('fuel_capacity') or '',r.get('fault') or '')].append(r)
for (cal,fuel,fault),group in by.items():data.append([('CAL '+cal if cal else 'FUEL '+fuel if fuel else fault or 'control'),len(group),stat(val(group,'attempted'),0),stat(val(group,'receipts'),0),stat(val(group,'closed'),0),stat(val(group,'closed_drain_seconds'))])
if data:table(['条件','轮次','实际发送','最终收据','最终闭合','最晚成功闭合超出窗口 s'],data)
if by:
    table(['条件','未取得收据','已取得收据但未闭合','活动组织最终 FUEL 支出','公共池最终 Held'],[(('CAL '+cal if cal else 'FUEL '+fuel if fuel else fault or 'control'),stat(val(group,'attempted_without_receipt'),0),stat(val(group,'receipts_without_closure'),0),stat(val(group,'active_pool_spent_fuel'),0),stat(val(group,'final_fuel_held'),0)) for (cal,fuel,fault),group in by.items()])
    add('限额组的非零退出和超时保留在原始记录中。最后成功付款的闭合时间不是未完成请求的总等待时间；客户端还按配置等待至 60 s 排空期限。池余额包含预热成本。未取得收据表示认证请求未完成，不能直接解释为已成功付款的资金丢失。\n')
add('限额与暂停矩阵统一经过 0 ms 代理，使用本组 control 作对照，不直接与无代理主混合负载计算时延比例。故障实验暂停一个成员或一个委员会进程 5 s，保留状态并恢复进程；它测量暂停容错，不等同丢盘、任意 Byzantine 或长时间网络分区。信号时间和目标进程核验另存 `fault-events.jsonl`。\n')
add('## 5. 拥堵与受控网络')
data=[]
for bps in ['1','2500']:
    for cls in ['ordinary-base','ordinary-priority','source-recovery']:
        by=collections.defaultdict(list)
        for r in con:
            if r['reserved_bps']==bps and r['traffic_class']==cls:by[r['run']].append(float(r['submit_to_block_ms']))
        if by:data.append([str(int(bps)/100)+'%',cls,len(by),stat([statistics.median(x) for x in by.values()])])
if data:table(['保留字节比例','类型','轮次','每轮提交至区块可见 P50 ms'],data)
add('拥堵使用 32 KiB 区块上限，60 笔基础/优先付款和 4 笔来源补交。0.01% 是近零保留配置，不叫关闭。等待从同一客户端首次实际提交到验证区块可见，包含共识和观察时间；客户端未观察完成的积压不等于节点内存池长度。\n')
data=[]
for delay in [0,10,40]:
    for arm in ['final','fastpay-official','fastpay-tuned']:
        v=[r for r in select('formal-rtt',arm) if float(r['rtt_ms'])==delay]
        if v:data.append([delay,labels[arm],len(v),stat([x/1000 for x in val(v,'chain_total_ms')])])
if data:table(['每链路配置 RTT ms','方案','轮次','100 笔末笔收据 s'],data)
add('所有 RTT 条件，包括 0 ms，都经过同一代理。代理对每方向数据分块施加半个 RTT 的保留时间，不加带宽上限；配置和实际链路统计保存在 `extended.json`。该实验是受控链路延迟，不是公网部署测量。\n')
add('## 6. 数据完整性、图表与结论范围')
add('\n完整逐轮统计在 `analysis/`；原始服务数据在 WSL 实验根目录及交付的数据包。图 A、C 优先用于正文：分别回答连续付款速度和费用确定性；图 B、D 展示来源恢复和拥堵处理。图题见 `FIGURE-CAPTIONS.md`。\n')
add('WSL 墙钟回跳曾使旧分析器误判一次已完成的链运行；本轮统一使用原生 Go 单调持续时间重算全部相关数据，保留原失败退出码和旧分析器。混合负载窗口也按相同原则修正。没有因此选择性重跑或删掉慢轮次。\n')
add('费用结果支持终稿在这些真实执行路径中的用户成本确定、正常乱序中立、超时直接归责及 FUEL 守恒。性能结果必须按链长、基线运行时和终点分别陈述：不能把某一组领先写成全面优于 FastPay，也不能把 C3 相对 No C3 的额外开销省略。F1–F6 的一般性形式证明仍需完成。\n')
(here/'RESULTS.zh-CN.md').write_text('\n'.join(out)+'\n',encoding='utf-8')
print(here/'RESULTS.zh-CN.md')
