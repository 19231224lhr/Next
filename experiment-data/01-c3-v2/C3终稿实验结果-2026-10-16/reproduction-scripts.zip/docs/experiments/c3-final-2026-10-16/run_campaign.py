"""Serial minimum paper campaign; refuses to overwrite or silently skip failures."""
import argparse
import json
import pathlib
import subprocess
import sys
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root',type=pathlib.Path,required=True)
p.add_argument('--wait-orders',action='store_true')
a = p.parse_args()
here = pathlib.Path(__file__).resolve().parent
if a.wait_orders:
    while True:
        path = a.root/'formal-orders/status.jsonl'
        rows = [json.loads(x) for x in path.read_text().splitlines()] if path.exists() else []
        if any(x['returncode'] for x in rows):
            raise SystemExit('order validation failed')
        if len(rows) == 15:
            break
        time.sleep(3)
phases = [
    ('formal-switches',['--suite','switches','--repeats','5','--length','1000','--arms','final-plain,final,final-continuation']),
    ('formal-chain100',['--suite','chain','--repeats','7','--length','100']),
    ('formal-chain1000',['--suite','chain','--repeats','7','--length','1000']),
    ('formal-mixed',['--suite','mixed','--repeats','5','--arms','baseline,legacy,final','--rate','100','--duration','30']),
    ('formal-delays',['--suite','delays','--repeats','5','--count','20','--delays','0,500,1500,4000']),
    ('formal-congestion',['--suite','congestion','--repeats','5']),
    ('diagnostic-preparation',['--suite','chain','--repeats','3','--length','1000','--arms','final','--trace','--build-profile']),
]
(a.root/'campaign-plan.json').write_text(json.dumps(phases,indent=2)+'\n')
with (a.root/'campaign-status.jsonl').open('x') as status:
    for name, extra in phases:
        command = [sys.executable,str(here/'run_matrix.py'),'--root',str(a.root/name),
                   '--final-bin',str(a.root/'final-bin'),'--old-bin',str(a.root/'baseline-bin'),
                   '--fixtures',str(a.root/'fixtures'),*extra]
        print('PHASE '+name,flush=True)
        with (a.root/(name+'-campaign.log')).open('x') as log:
            process = subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
            try:
                result = process.wait()
            except BaseException:
                process.terminate()
                try: process.wait(timeout=55)
                except subprocess.TimeoutExpired: process.kill();process.wait()
                raise
        status.write(json.dumps({'phase':name,'returncode':result,'ended_ns':time.time_ns(),'command':command})+'\n')
        status.flush()
        print('END '+name+' '+str(result),flush=True)
        if result:
            raise SystemExit(result)
