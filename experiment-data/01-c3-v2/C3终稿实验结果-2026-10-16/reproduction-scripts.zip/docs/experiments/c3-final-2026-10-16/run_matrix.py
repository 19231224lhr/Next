#!/usr/bin/env python3
"""Predeclared sequential final-C3 experiments, preserving every outcome."""
import argparse
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import sys
import time
from monitor import Monitor

HERE = pathlib.Path(__file__).resolve().parent


def jobs(args):
    rows = []
    if args.suite == 'orders':
        cases = ['source-first', 'child-first', 'compensated']
        for r in range(args.repeats):
            for case in cases[r % 3:] + cases[:r % 3]:
                rows.append(dict(repeat=r+1, arm='final', workload='fees',
                                 case=case, count=1, base_fee=2, fixture='fees-1'))
    elif args.suite == 'delays':
        delays = [int(v) for v in args.delays.split(',')]
        for r in range(args.repeats):
            for delay in delays[r % len(delays):] + delays[:r % len(delays)]:
                rows.append(dict(repeat=r+1, arm='final', workload='fees', case='delay',
                                 count=args.count, delay_ms=delay, base_fee=2, fixture=f'fees-{args.count}'))
    elif args.suite == 'congestion':
        for r in range(args.repeats):
            for bps in ([1,2500] if r%2 == 0 else [2500,1]):
                rows.append(dict(repeat=r+1, arm='final', workload='congestion', count=60,
                                 sources=4, block_bytes=32768, reserved_bps=bps,base_fee=2,fixture='congestion-final'))
    else:
        arms = args.arms.split(',')
        for r in range(args.repeats):
            order = arms[r % len(arms):]+arms[:r % len(arms)]
            if r % 2:
                order.reverse()
            for arm in order:
                workload = 'chain' if args.suite == 'switches' else args.suite
                rows.append(dict(repeat=r+1, arm=arm, workload=workload,
                                 length=args.length, rate=args.rate, duration=args.duration,
                                 fixture=f'{workload}-{"final" if arm.startswith("final") else arm}'))
    return rows


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=pathlib.Path, required=True)
    p.add_argument('--final-bin', type=pathlib.Path, required=True)
    p.add_argument('--old-bin', type=pathlib.Path, required=True)
    p.add_argument('--fastpay-official', type=pathlib.Path, default='/home/qyinf/.local/share/next-baseline-tools/fastpay-target/release')
    p.add_argument('--fastpay-tuned', type=pathlib.Path, default='/home/qyinf/.local/share/next-baseline-tools/fastpay-runtime-sensitivity-target/release')
    p.add_argument('--fixtures', type=pathlib.Path, required=True)
    p.add_argument('--suite', choices=['orders', 'delays', 'chain', 'mixed','switches','congestion'], required=True)
    p.add_argument('--arms', default='baseline,legacy,final,fastpay-official,fastpay-tuned')
    p.add_argument('--repeats', type=int, default=5)
    p.add_argument('--length', type=int, default=100)
    p.add_argument('--rate', type=int, default=100)
    p.add_argument('--duration', type=int, default=30)
    p.add_argument('--count', type=int, default=20)
    p.add_argument('--delays', default='0,500,1500,4000')
    p.add_argument('--gomaxprocs', type=int, default=1)
    p.add_argument('--trace', action='store_true')
    p.add_argument('--build-profile', action='store_true')
    p.add_argument('--continue-on-failure', action='store_true')
    p.add_argument('--start-index', type=int, default=0, help='Resume remaining predeclared jobs in a NEW directory; retain original reports separately')
    a = p.parse_args()
    a.root.mkdir(parents=True, exist_ok=False)
    a.fixtures.mkdir(parents=True, exist_ok=True)
    plan = jobs(a)
    manifest = {'jobs':plan, 'created_ns':time.time_ns(), 'affinity':sorted(os.sched_getaffinity(0)),
                'arguments':{k:str(v) if isinstance(v,pathlib.Path) else v for k,v in vars(a).items()},
                'harness_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
                'monitor_interval_seconds':0.5,
                'resource_notes':'CPU and IO sampled process-tree deltas; RSS instantaneous sum; loopback counters are host-wide. Setup included, filter by native timing for workload-only statistics.'}
    (a.root/'plan.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with (a.root/'status.jsonl').open('x') as status:
        for index, job in enumerate(plan):
            if index < a.start_index:
                continue
            name = f'{index:03d}-r{job["repeat"]}-{job["arm"]}-{job.get("case",a.suite)}'
            if 'delay_ms' in job:
                name += f'-{job["delay_ms"]}ms'
            if 'reserved_bps' in job:
                name += f'-reserve{job["reserved_bps"]}'
            directory = a.root/name
            env = dict(os.environ, GOMAXPROCS=str(a.gomaxprocs))
            for key in ['FASTPAY_RUNTIME_THREADS','UTXO_CHAIN_CPU_PROFILE','UTXO_CHAIN_BUILD_PROFILE','UTXO_CHAIN_CPU_FOREGROUND_ONLY','UTXO_SETTLEMENT_TRACE']:
                env.pop(key, None)
            if job['arm'].startswith('fastpay'):
                if a.suite != 'chain':
                    raise ValueError('FastPay included only for common chain endpoint')
                binary = a.fastpay_official if job['arm']=='fastpay-official' else a.fastpay_tuned
                if job['arm']=='fastpay-tuned':
                    env['FASTPAY_RUNTIME_THREADS']='1'
                command = [sys.executable,str(HERE.parent/'baseline-design-2026-10-13/run_fastpay.py'),
                           '--bin',str(binary),'--run-dir',str(directory),'--workload','chain',
                           '--length',str(a.length),'--client-mode','receiver-confirmed','--protocol','Tcp']
            else:
                binary = a.final_bin if job['arm'].startswith('final') else a.old_bin
                variant = 'final' if job['arm'].startswith('final') else ('c3' if job['arm']=='legacy' else job['arm'])
                command = [sys.executable,str(HERE/'run_final.py'),'--bin',str(binary),'--run-dir',str(directory),
                           '--variant',variant,'--workload',job['workload']]
                for key in ['case','count','delay_ms','base_fee','length','rate','duration','sources','block_bytes','reserved_bps']:
                    if key in job:
                        command += ['--'+key.replace('_','-'),str(job[key])]
                fixture = a.fixtures/job['fixture']
                command += ['--fixture' if fixture.exists() else '--save-fixture',str(fixture)]
                command += ['--gateway-mode', 'plain' if job['arm']=='final-plain' else ('continuation' if job['arm']=='final-continuation' else 'compact')]
                if a.trace:
                    command.append('--trace')
                if a.build_profile:
                    env['UTXO_CHAIN_BUILD_PROFILE']='1'
            print('START '+name,flush=True)
            start = time.time_ns()
            with (a.root/(name+'.log')).open('x') as log:
                proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env)
                monitor = Monitor(proc.pid, a.root/(name+'-resources.csv'))
                try:
                    code = proc.wait()
                except BaseException:
                    proc.send_signal(signal.SIGTERM)
                    try:
                        proc.wait(timeout=55)
                    except subprocess.TimeoutExpired:
                        proc.kill();proc.wait()
                    raise
                finally:
                    monitor.close()
            row = {**job,'name':name,'start_ns':start,'end_ns':time.time_ns(),'returncode':code,'command':command,
                   'binary_sha256':{n:hashlib.sha256((binary/n).read_bytes()).hexdigest() for n in (['server','examples/baseline_client'] if job['arm'].startswith('fastpay') else ['payctl','member','gateway','committee'])}}
            status.write(json.dumps(row)+'\n');status.flush()
            print('END '+json.dumps({'name':name,'returncode':code}),flush=True)
            if code and not a.continue_on_failure:
                raise SystemExit(code)


if __name__ == '__main__':
    main()
