"""Mixed timing adapter checks only; no services or load."""
import copy
import unittest
from metrics import mixed_metrics


def fixture():
    begin=10_000_000_000
    start=dict(StartedNS=begin-500_000_000,FormalNS=begin,EndSendNS=begin+2_000_000_000)
    def row(index,scheduled,lag,fast,public,member,wall_shift=0):
        sent=begin+scheduled+lag+wall_shift
        return dict(Index=index,ScheduledNS=begin+scheduled,SentNS=sent,ReadyNS=sent+fast,
            PublicNS=sent+public,MemberNS=[sent+member]*4,CertificateBytes=100,
            Monotonic=dict(ScheduleLagNS=lag,FastNS=fast,PublicNS=public,MemberNS=[member]*4))
    report=dict(Options=dict(Rate=2),Samples=[
        row(0,-100_000_000,0,20_000_000,30_000_000,40_000_000), # excluded warmup
        row(1,1_800_000_000,50_000_000,100_000_000,200_000_000,250_000_000,-1_000_000_000),
        row(2,100_000_000,10_000_000,40_000_000,60_000_000,90_000_000,-2_000_000_000),
        dict(Index=3,ScheduledNS=begin+300_000_000,SentNS=0)])
    return report,start


class MixedMonotonicTests(unittest.TestCase):
    def test_window_reconstruction_ignores_wall_rollback_and_excludes_warmup(self):
        report,start=fixture();original=copy.deepcopy(report);result=mixed_metrics(report,start)
        self.assertEqual(result['formal_samples'],3);self.assertEqual(result['attempted'],2)
        self.assertEqual(result['unsent'],1);self.assertEqual(result['receipts'],2)
        self.assertEqual(result['closed'],2);self.assertEqual(result['in_window_receipts'],2)
        self.assertEqual(result['in_window_public'],1)
        self.assertAlmostEqual(result['public_drain_seconds'],.05)
        self.assertAlmostEqual(result['closed_drain_seconds'],.1)
        self.assertGreater(result['wall_clock_diagnostic_segments'],0)
        self.assertEqual(original,report)

    def test_missing_monotonic_phase_does_not_fall_back_to_wall(self):
        report,start=fixture();del report['Samples'][1]['Monotonic']['ScheduleLagNS']
        with self.assertRaises(ValueError):mixed_metrics(report,start)

    def test_partial_member_observation_does_not_become_closed(self):
        report,start=fixture();report['Samples'][1]['MemberNS'][3]=0
        result=mixed_metrics(report,start)
        self.assertEqual(result['closed'],1)
        self.assertEqual(result['completion_fraction'],.5)

    def test_window_end_is_exclusive_and_zero_schedule_lag_is_valid(self):
        report,start=fixture()
        sample=report['Samples'][1]
        sample['Monotonic']['ScheduleLagNS']=0
        sample['Monotonic']['FastNS']=200_000_000
        result=mixed_metrics(report,start)
        self.assertEqual(result['in_window_receipts'],1)
        self.assertEqual(result['receipt_drain_seconds'],0)

    def test_missing_observed_public_duration_is_rejected(self):
        report,start=fixture();del report['Samples'][1]['Monotonic']['PublicNS']
        with self.assertRaises(ValueError):mixed_metrics(report,start)

    def test_failed_request_is_counted_separately_from_unclosed_receipt(self):
        report,start=fixture()
        failed=report['Samples'][1]
        failed.update(ReadyNS=0,PublicNS=0,MemberNS=[0]*4,Attempts=3,Error='context deadline exceeded')
        receipt=report['Samples'][2]
        receipt.update(MemberNS=[0]*4,Attempts=1)
        result=mixed_metrics(report,start)
        self.assertEqual(result['attempted'],2)
        self.assertEqual(result['attempted_without_receipt'],1)
        self.assertEqual(result['receipts_without_closure'],1)
        self.assertEqual(result['http_attempts'],4)
        self.assertEqual(result['payments_with_retries'],1)
        self.assertEqual(result['requests_ended_with_error'],1)


if __name__=='__main__':unittest.main()
