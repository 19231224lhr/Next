"""Package the measured sources, scripts and evidence without changing Git state."""
import hashlib,json,pathlib,shutil,zipfile

here=pathlib.Path(__file__).resolve().parent
repo=here.parents[2]
dest=repo.parent/'C3终稿实验结果-2026-10-16'
dest.mkdir(exist_ok=True)

def archive(target,entries):
    manifest=[]
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,path,expected in sorted(entries):
            data=path.read_bytes();digest=hashlib.sha256(data).hexdigest()
            if expected and digest!=expected:raise ValueError('Snapshot changed: '+str(path))
            z.writestr(name,data);manifest.append(dict(path=name,bytes=len(data),sha256=digest))
        z.writestr('PACKAGE-MANIFEST.json',json.dumps(manifest,indent=2))
    return dict(path=target.name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),files=len(manifest))

entries=[]
dependency=json.loads((here/'baseline-dependency-manifest.json').read_text())['files']
for version in ['baseline','final']:
    m=json.loads((here/(version+'-manifest.json')).read_text());source=pathlib.Path(m['source_snapshot'])
    selected={r['path']:r for r in m['files']}
    if version=='final':
        for r in json.loads((here/'final-testdata-manifest.json').read_text()):selected[r['path']]=r
        r=json.loads((here/'final-module-boundary-manifest.json').read_text());selected[r['path']]=r
    for name,r in selected.items():entries.append((version+'/'+name,source/name,r['sha256']))
    for r in dependency:entries.append((version+'/.scratch/comet-src/'+r['path'],source/'.scratch/comet-src'/r['path'],r['sha256']))
packages=[archive(dest/'measured-source-snapshots.zip',entries)]

entries=[]
for p in here.iterdir():
    if p.is_file() and p.suffix=='.py':entries.append((p.relative_to(repo).as_posix(),p,None))
base=here.parent/'baseline-design-2026-10-13'
for name in ['run_next.py','run_fastpay.py','fastpay_client.rs','FastPay-Cargo.lock','build_fastpay.sh']:
    p=base/name;entries.append((p.relative_to(repo).as_posix(),p,None))
runtime=here.parent/'fastpay-runtime-sensitivity-2026-10-14'
for name in ['prepare.py','README.md']:
    p=runtime/name;entries.append((p.relative_to(repo).as_posix(),p,None))
for name in ['runtime-only.patch','runtime-provenance.json','Cargo.lock']:
    p=repo/'.scratch/fastpay-runtime-sensitivity'/name;entries.append(('fastpay-runtime/'+name,p,None))
for name in ['audit_panel_alignment.py','audit_pdf_text.py','audit_figure_collisions.py','validate_figure.py']:
    p=pathlib.Path('C:/Users/Bocchi/.codex/skills/nature-figure/scripts')/name
    entries.append(('figure-audit-tools/'+name,p,None))
packages.append(archive(dest/'reproduction-scripts.zip',entries))

for folder in ['analysis','figures']:
    shutil.copytree(here/folder,dest/folder,dirs_exist_ok=True)
for name in ['RESULTS.zh-CN.md','IMPLEMENTATION.zh-CN.md','implementation.md','COMPLETION.zh-CN.md','EVIDENCE.zh-CN.md','REPRODUCE.md','MEASUREMENT-NOTES.md','FIGURE-CAPTIONS.md','environment.json','source-delta.zip','source-delta.patch','source-changes.json','raw-experimental-data.zip','final-manifest.json','final-build.json','baseline-dependency-manifest.json','baseline-manifest.json','final-tagged-tests.log']:
    shutil.copy2(here/name,dest/name)
proof=dest/'provenance';proof.mkdir(exist_ok=True)
for p in here.iterdir():
    if p.is_file() and (p.suffix in ('.json','.txt','.log') or p.name in ('review.md','implementation.md')):
        shutil.copy2(p,proof/p.name)
for name in ['gpt-measurement-review.png','gpt-results-review.png']:shutil.copy2(here/name,proof/name)
readme='''# Next 终稿 C3 实验交付

先看 [结果报告](RESULTS.zh-CN.md)，再看 [实验完成表](COMPLETION.zh-CN.md) 和 [安全证据](EVIDENCE.zh-CN.md)。

- `analysis/`：逐轮 CSV、配对对照、费用状态与汇总。
- `figures/`：PDF/SVG 矢量图、300 dpi PNG，以及绘图检查记录；图题见 `FIGURE-CAPTIONS.md`。
- `raw-experimental-data.zip`：真实服务报告、运行配置、日志和失败记录，含逐文件 SHA-256 清单。排除了实验身份私钥与数据库；原始完整运行仍保存在 WSL。
- `measured-source-snapshots.zip`：修改前 baseline 与终稿 final 源码，以及各自的本地 CometBFT 依赖。包含已有公开测试用密钥素材，不包含实验钱包私钥。
- `source-delta.zip` / `.patch`：两份实际测量源码之间的修改，方便审查。
- `reproduction-scripts.zip`：保留仓库相对目录的实验、统计、绘图和 FastPay 构建脚本。绘图脚本的 `--audit-dir` 可指向包内 `figure-audit-tools/`。
- `provenance/`：构建与源码哈希、测试输出、环境、审查和 GPT 讨论记录。

复现方法见 `REPRODUCE.md`。先分别解压源码并构建，再按脚本指定新的运行目录；不要覆盖本轮原始数据。FastPay 官方提交、客户端适配器及单 worker 变体分别保留，不混为一个基线。

代码尚未自动提交或推送。实验验证不代替 F1–F6 的一般性数学证明。
'''
(dest/'README.md').write_text(readme,encoding='utf-8')
files=[]
for p in sorted(dest.rglob('*')):
    if p.is_file() and p.name!='DELIVERY-MANIFEST.json':
        h=hashlib.sha256()
        with p.open('rb') as f:
            for block in iter(lambda:f.read(1048576),b''):h.update(block)
        files.append(dict(path=p.relative_to(dest).as_posix(),bytes=p.stat().st_size,sha256=h.hexdigest()))
(dest/'DELIVERY-MANIFEST.json').write_text(json.dumps(dict(source=str(here),files=files,packages=packages),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(destination=str(dest),files=len(files),bytes=sum(r['bytes'] for r in files)),ensure_ascii=False))
