"""Read final budget state after the unchanged mixed workload, before shutdown."""
import hashlib,json,pathlib,urllib.request
import run_extended

original=run_extended.Extension.restore_fault
def restore_and_capture(self):
    original(self)
    marker=self.root/'reports/e8-report.json'
    if getattr(self,'budget_captured',False) or not marker.exists():return
    self.budget_captured=True
    result=dict(scope='after native workload and drain, before service shutdown',pools=[],members=[],errors=[],harness_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
    network=run_extended.read(self.root/'config/network.json')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def get(url):
        try:
            with opener.open(url,timeout=3) as response:return json.load(response)
        except Exception as exc:result['errors'].append(dict(url=url,error=repr(exc)));return None
    for issuer in network['Direct']['C3']['Issuers']:
        key=issuer['Funding']['Key'];url=network['CommitteeURLs'][0].rstrip('/')+'/v3/c3/pools/'+key['Account']+'/'+str(key['Version'])
        result['pools'].append(dict(url=url,snapshot=get(url)))
    lab=run_extended.read(self.root/'lab.json')
    for node in lab['Nodes']:
        if node['Binary']=='member':
            url=node['URL'].rstrip('/')+'/debug/budget';result['members'].append(dict(name=node['Name'],url=url,snapshot=get(url)))
    run_extended.save(self.root/'reports/final-budgets.json',result)

run_extended.Extension.restore_fault=restore_and_capture
if __name__=='__main__':run_extended.main()
