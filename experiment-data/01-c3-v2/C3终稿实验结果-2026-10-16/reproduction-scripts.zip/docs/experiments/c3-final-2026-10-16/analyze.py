"""Reduce all registered real runs, including failures, without pooling replicates."""
import argparse, collections, csv, json, math, pathlib, statistics
from metrics import distribution, quantile, mixed_metrics
from run_final import chain_result

def read(p): return json.loads(p.read_text())
def write_csv(p,rows):
    if not rows: return
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with p.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def identity(v): return bytes(v).hex() if isinstance(v,list) else v
def escrow(stage,who): return ((stage.get(who) or {}).get('Record') or {}).get('Escrow') or {}

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True)
    rows=[];fee_rows=[];congestion=[];hops=[];fee_stages=[];resources=[];build_stages=[];pool_samples=[];queue_samples=[];local_spans=[];link_samples=[]
    for status in sorted(a.root.glob('*/status.jsonl')):
        suite=status.parent.name
        if not suite.startswith(('formal-','diagnostic-')): continue
        for line in status.read_text().splitlines():
            job=json.loads(line);directory=status.parent/job['name'];r=dict(suite=suite.replace('-remaining',''),run=job['name'],repeat=job['repeat'],arm=job['arm'],returncode=job['returncode'],workload=job['workload'],length=job.get('length'),delay_ms=job.get('delay_ms'),reserved_bps=job.get('reserved_bps'),rtt_ms=job.get('rtt_ms'),fault=job.get('fault'),cal_capacity=job.get('cal_capacity'),fuel_capacity=job.get('fuel_capacity'))
            if (directory/'result.json').exists():
                r.update({k:v for k,v in read(directory/'result.json').items() if isinstance(v,(str,int,float,bool)) or v is None})
            elif (directory/'extended-result.json').exists():
                r.update({k:v for k,v in read(directory/'extended-result.json').items() if isinstance(v,(str,int,float,bool)) or v is None})
            elif (directory/'independent-result.json').exists():
                d=read(directory/'independent-result.json');r.update({k:v for k,v in d.items() if isinstance(v,(str,int,float,bool)) or v is None});r['data_valid']=d.get('completed')==job.get('count') and d.get('closure_status')=='complete'
            native=directory/'reports/chain-v4.json'
            try:
                if native.exists():
                    d=read(native);checked=chain_result(d,d['Requested']);hs=d['Hops'];r.update(distribution(checked['samples_ms'],'receipt_ms'))
                    r.update(chain_total_ms=d['FastChainMS'],public_chain_ms=d['PublicChainMS'],closed_chain_ms=d['ClosedChainMS'],completed=len(hs),closure_status=checked['closure_status'],receipt_status=checked['receipt_status'],wall_clock_diagnostic_segments=len(checked['wall_clock_discontinuities']),data_valid=True,
                             build_total_ms=sum(h['BuildMS'] for h in hs),following_build_ms=sum(h['BuildMS'] for h in hs[1:]),receive_total_ms=sum(h['FastMS'] for h in hs),certificate_bytes_p50=quantile([h['CertificateBytes'] for h in hs],.5))
                    r['following_gap_ms']=r['chain_total_ms']-r['receive_total_ms']
                    for h in hs:
                        hops.append(dict(suite=r['suite'],run=r['run'],repeat=r['repeat'],arm=r['arm'],hop=h['Hop'],build_ms=h['BuildMS'],receipt_ms=h['FastMS'],sent_offset_ms=h['SentOffsetMS'],ready_offset_ms=h['ReadyOffsetMS'],public_offset_ms=h['FinalOffsetMS'],closed_offset_ms=h['MemberOffsetMS'],request_bytes=h['RequestBytes'],certificate_bytes=h['CertificateBytes'],attempts=h['Attempts'],progress_errors=h['ProgressErrors']))
                        for category in ('BuildStagesMS','BuildSaveStagesMS'):
                            for stage,value in (h.get(category) or {}).items():
                                build_stages.append(dict(run=r['run'],hop=h['Hop'],category=category,stage=stage,duration_ms=value))
                fp=directory/'native-client.json'
                if fp.exists():
                    d=read(fp);samples=d.get('samples_ms') or d.get('request_to_receipt_ms');r.update(distribution(samples,'receipt_ms'))
                    builds=d.get('build_ms') or [];r.update(chain_total_ms=d.get('chain_total_ms'),completed=d['completed'],data_valid=d['completed']==r['length'] and d.get('principal_conserved') is True,receipt_status='complete' if d['completed']==r['length'] else 'incomplete',endpoint=d['endpoint'],following_build_ms=sum(builds[1:]),build_total_ms=sum(builds),receive_total_ms=sum(samples))
                    if r.get('chain_total_ms') is not None:r['following_gap_ms']=r['chain_total_ms']-r['receive_total_ms']
                mixed=directory/'reports/e8-report.json'
                if mixed.exists():
                    m=mixed_metrics(read(mixed),read(directory/'reports/e8-start.json'));r.update({k:v for k,v in m.items() if isinstance(v,(str,int,float,bool)) or v is None});r['data_valid']=True
                fee=directory/'reports/c3-fees.json'
                if fee.exists():
                    d=read(fee);pools=d.get('FinalPools') or [];r.update(case=d['Case'],pairs=len(d['Pairs']),fuel_conserved=d.get('FUELConserved'),data_valid=not d.get('Error') and d.get('FUELConserved') is True)
                    for pair in d['Pairs']:
                        closed=next((s for s in pair['Stages'] if s['Name']=='closed'),pair['Stages'][-1]);src=escrow(closed,'Source');child=escrow(closed,'Child')
                        f=dict(suite=r['suite'],run=r['run'],repeat=r['repeat'],case=d['Case'],delay_ms=d['SourceDelayNS']/1e6,pair=pair['Index'],source_quote_cal=pair['Source']['ServiceFeeCAL'],child_quote_cal=pair['Child']['ServiceFeeCAL'],user_fuel=pair['Source']['FeeNet']+pair['Child']['FeeNet'],source_receive_cal=pair['Source']['FinalCoin']['Output']['Amount'],child_receive_cal=pair['Child']['FinalCoin']['Output']['Amount'],source_budget=src.get('Commitment',{}).get('Budget'),source_spent=src.get('Rewards',0)+src.get('Reflow',0),child_spent=child.get('Rewards',0)+child.get('Reflow',0),rewards=src.get('Rewards',0)+child.get('Rewards',0),reflow=src.get('Reflow',0)+child.get('Reflow',0),released=src.get('Released',0)+child.get('Released',0),held=src.get('Held',0)+child.get('Held',0),compensated=any(s['Name']=='compensated-before-source' for s in pair['Stages']),recovered=bool(pair['Source'].get('RecoveredOutputs')),source_public_ms=pair['Source']['PublicOffsetNS']/1e6,child_public_ms=pair['Child']['PublicOffsetNS']/1e6,closed_ms=closed['OffsetNS']/1e6,source_receipt_ms=pair['Source']['ReceiptNS']/1e6,child_receipt_ms=pair['Child']['ReceiptNS']/1e6,replay_error=pair.get('ReplayError',''),fuel_conserved=d['FUELConserved'])
                        fee_rows.append(f)
                        for s in pair['Stages']:
                            e=escrow(s,'Source');fee_stages.append(dict(run=r['run'],pair=pair['Index'],stage=s['Name'],offset_ms=s['OffsetNS']/1e6,source_held=e.get('Held'),source_rewards=e.get('Rewards'),source_reflow=e.get('Reflow'),source_released=e.get('Released'),obligation_status=(s.get('Obligation') or {}).get('Status')))
                    if pools:r.update(global_rewards=pools[0]['Rewards'],issuer_spent=sum(x['Spent'] for x in pools),issuer_held=sum(x['Held'] for x in pools),issuer_revenue_cal=sum(x.get('CALRevenue',0) for x in pools),credited_fuel=sum(x['Funding']-x['OriginalFunding'] for x in pools),epoch=pools[0]['Epoch']['Epoch'])
                    snapshots=d.get('Samples') or []
                    if snapshots:r['sampled_peak_public_held_fuel']=max(sum(p['Held'] for p in s['Pools']) for s in snapshots)
                    for s in snapshots:
                        for i,pool in enumerate(s['Pools']):
                            pool_samples.append(dict(suite=r['suite'],run=r['run'],offset_ms=s['OffsetNS']/1e6,pool_index=i,held_fuel=pool['Held'],spent_fuel=pool['Spent'],free_fuel=pool['Free'],funding_fuel=pool['Funding'],cal_revenue=pool.get('CALRevenue'),epoch=pool['Epoch']['Epoch'],cumulative_reflow_fuel=pool.get('PoolReflow')))
                cp=directory/'reports/c3-congestion.json'
                if cp.exists():
                    d=read(cp);r.update(data_valid=not d.get('Error') and d.get('FUELConserved') is True,fuel_conserved=d.get('FUELConserved'))
                    for item in d['Rows']:
                        pay=item['Payment'];attempts=item.get('HTTPAttempts') or []
                        if not attempts: continue
                        first=attempts[0]['StartOffsetNS']/1e6;seen=item['VerifiedBlockSeenOffsetNS']/1e6
                        congestion.append(dict(suite=r['suite'],run=r['run'],repeat=r['repeat'],reserved_bps=r['reserved_bps'],traffic_class=item['Class'],fact=identity(pay['Fact']),first_submit_ms=first,verified_block_seen_ms=seen,submit_to_block_ms=seen-first,execution_height=pay['ExecutionHeight'],priority_fee_cal=item['PriorityFeeCAL'],priority_reward_fuel=item['PriorityRewardFUEL'],receipt_ms=pay['ReceiptNS']/1e6,http_attempts=len(attempts),planned_order=item['PlannedSubmissionOrder'],actual_order=item['ActualSubmissionOrder']))
            except Exception as e:r.update(data_valid=False,analysis_error=repr(e))
            trace=directory/'reports/settlement-traces.json'
            if trace.exists():
                for payment in read(trace):
                    for record in payment.get('records',[]):
                        for name,start,end in [('mempool_check','MempoolEnterUnixNS','MempoolCheckedUnixNS'),('final_check','FinalCheckStartUnixNS','FinalCheckDoneUnixNS'),('execute','ExecuteStartUnixNS','ExecuteDoneUnixNS'),('commit','CommitStartUnixNS','CommittedUnixNS')]:
                            if record.get(start,0)>0 and record.get(end,0)>0:
                                delta=record[end]-record[start]
                                local_spans.append(dict(run=r['run'],hop=payment['hop'],span=name,duration_ms=delta/1e6,negative_wall_interval=delta<0,timing='same committee process wall timestamps; diagnostic only, clock jumps possible',scope='commit is block-scoped; do not sum repeated transaction copies'))
            rows.append(r)
            extension=directory/'extended.json'
            if extension.exists():
                for name,link in read(extension).get('links',{}).items():
                    for direction in ('client_to_target','target_to_client'):
                        v=link[direction]
                        link_samples.append(dict(suite=r['suite'],run=r['run'],arm=r['arm'],rtt_ms=r.get('rtt_ms'),link=name,direction=direction,bytes=v['bytes'],chunks=v['chunks'],mean_hold_ms=v['hold_ns']/v['chunks']/1e6 if v['chunks'] else None,max_hold_ms=v['max_hold_ns']/1e6,queue_high_water=v['queue_high_water'],connection_errors=len(link.get('errors',[])),scope='whole run including startup, idle background and drain'))
            budgets=directory/'reports/final-budgets.json'
            if budgets.exists():
                d=read(budgets);ps=[x['snapshot'] for x in d['pools'] if x.get('snapshot')]
                if ps:
                    r.update(final_fuel_spent=sum(x['Spent'] for x in ps),final_fuel_held=sum(x['Held'] for x in ps),final_fuel_free=sum(x['Free'] for x in ps),active_pool_free_fuel=ps[0]['Free'],active_pool_spent_fuel=ps[0]['Spent'],final_committee_rewards=ps[0]['Rewards'],final_pool_funding_identity=all(x['Funding']==x['Free']+x['Held']+x['Spent'] for x in ps),final_budget_snapshot_errors=len(d['errors']))
            resource=status.parent/(job['name']+'-resources.csv')
            if resource.exists():
                data=list(csv.DictReader(resource.open()))
                if data:
                    resources.append(dict(suite=r['suite'],run=r['run'],arm=r['arm'],repeat=r['repeat'],samples=len(data),cpu_seconds_sampled=max(float(x['cpu_seconds_sampled']) for x in data),peak_tree_rss_mib=max(int(x['rss_bytes']) for x in data)/1048576,read_bytes_sampled=max(int(x['read_bytes_sampled']) for x in data),write_bytes_sampled=max(int(x['write_bytes_sampled']) for x in data),host_loopback_delta_bytes=max(int(x['loopback_rx_bytes']) for x in data)-min(int(x['loopback_rx_bytes']) for x in data),scope='whole run including initialization and fixture setup'))
    queues=collections.defaultdict(list)
    for c in congestion:
        key=(c['run'],c['traffic_class'],c['reserved_bps'])
        queues[key].append((c['first_submit_ms'],1));queues[key].append((c['verified_block_seen_ms'],-1))
    for (run,cls,bps),events in queues.items():
        pending=0
        for instant,change in sorted(events):
            pending+=change
            queue_samples.append(dict(run=run,traffic_class=cls,reserved_bps=bps,offset_ms=instant,submitted_not_yet_observed=pending,scope='client-observed outstanding submissions, not node mempool length'))
    for name,data in [('runs',rows),('chain-hops',hops),('fees',fee_rows),('fee-stages',fee_stages),('pool-samples',pool_samples),('congestion-payments',congestion),('congestion-outstanding',queue_samples),('resource-boundaries',resources),('preparation-stages',build_stages),('settlement-local-spans',local_spans),('network-links',link_samples)]:write_csv(a.out/(name+'.csv'),data)
    groups=collections.defaultdict(list)
    for r in rows:
        if r.get('data_valid') is False:continue
        for metric in ('chain_total_ms','public_chain_ms','closed_chain_ms','receipt_ms_p50','receipt_ms_p95','following_build_ms','following_gap_ms','receive_total_ms','certificate_bytes_p50','receipt_goodput_per_s','completion_fraction','attempted','receipts','closed'):
            v=r.get(metric)
            if isinstance(v,(int,float)) and math.isfinite(v):groups[(r['suite'],r['arm'],r.get('rtt_ms'),r.get('cal_capacity'),r.get('fuel_capacity'),r.get('fault'),metric)].append(v)
    summary=[dict(suite=k[0],arm=k[1],rtt_ms=k[2],cal_capacity=k[3],fuel_capacity=k[4],fault=k[5],metric=k[6],n=len(v),median=statistics.median(v),minimum=min(v),maximum=max(v)) for k,v in groups.items()]
    write_csv(a.out/'summary.csv',summary)
    paired=[]
    for suite in sorted({r['suite'] for r in rows}):
        s=[r for r in rows if r['suite']==suite and r.get('data_valid') is not False]
        for repeat,rtt in sorted({(r['repeat'],r.get('rtt_ms')) for r in s},key=lambda x:(x[0],-1 if x[1] is None else x[1])):
            for control in ('baseline','legacy','fastpay-official','fastpay-tuned','final-plain','final-continuation'):
                f=[r for r in s if r['repeat']==repeat and r.get('rtt_ms')==rtt and r['arm']=='final'];b=[r for r in s if r['repeat']==repeat and r.get('rtt_ms')==rtt and r['arm']==control]
                if len(f)!=1 or len(b)!=1:continue
                for metric in ('chain_total_ms','receipt_ms_p50','following_build_ms','receive_total_ms'):
                    fv,bv=f[0].get(metric),b[0].get(metric)
                    if isinstance(fv,(int,float)) and isinstance(bv,(int,float)) and bv>0:paired.append(dict(suite=suite,repeat=repeat,rtt_ms=rtt,control=control,metric=metric,final=fv,baseline=bv,difference=fv-bv,reduction_percent=100*(1-fv/bv)))
    write_csv(a.out/'paired.csv',paired)
    (a.out/'analysis.json').write_text(json.dumps(dict(runs=len(rows),original_nonzero=sum(r['returncode']!=0 for r in rows),invalid=[r for r in rows if r.get('data_valid') is False],notes=['Run is replication unit; within-run payment percentiles precede between-run summary.','Wall-clock jumps retained; chain data validated from native same-process monotonic timing.','Original nonzero runner status is never erased; successful native data may be revalidated.','No pilot observations are mixed into formal summaries.']),indent=2)+'\n')
    print(json.dumps(dict(runs=len(rows),fee_pairs=len(fee_rows),congestion_payments=len(congestion),analysis_errors=[r for r in rows if r.get('analysis_error')]),ensure_ascii=False))
if __name__=='__main__':main()
