"""Wait for the serial primary campaign, then run its predeclared supplements."""
import json,pathlib,subprocess,sys,time
root=pathlib.Path(sys.argv[1]);here=pathlib.Path(__file__).resolve().parent
while True:
    path=root/'resume-campaign-status.jsonl'
    rows=[json.loads(s) for s in path.read_text().splitlines()] if path.exists() else []
    if any(r['returncode'] for r in rows):raise SystemExit('primary campaign stopped; inspect before continuing')
    if len(rows)==7:break
    time.sleep(5)
for suite in ['independent','rtt','capacity-faults']:
    command=[sys.executable,str(here/'run_supplements.py'),'--root',str(root),'--suite',suite]
    print('PHASE '+suite,flush=True)
    with (root/(suite+'-campaign.log')).open('x') as log:
        process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
        try:code=process.wait()
        except BaseException:
            process.terminate()
            try:process.wait(timeout=55)
            except subprocess.TimeoutExpired:process.kill();process.wait()
            raise
    print('END '+suite+' '+str(code),flush=True)
    if code:raise SystemExit(code)
