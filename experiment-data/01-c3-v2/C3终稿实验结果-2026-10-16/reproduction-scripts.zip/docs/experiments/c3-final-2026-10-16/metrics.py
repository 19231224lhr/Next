"""Measurement reductions; every sample retains its originating run."""
import math


def quantile(values, probability):
    values = sorted(values)
    if not values or not 0 <= probability <= 1 or any(not math.isfinite(v) for v in values):
        raise ValueError('invalid quantile input')
    index = (len(values) - 1) * probability
    lo = math.floor(index)
    hi = math.ceil(index)
    return values[lo] + (values[hi] - values[lo]) * (index - lo)


def distribution(values, prefix):
    if not values:
        return {prefix + suffix: None for suffix in ('_p50', '_p95', '_min', '_max')}
    return {prefix+'_p50': quantile(values, .5), prefix+'_p95': quantile(values, .95),
            prefix+'_min': min(values), prefix+'_max': max(values)}


def mixed_metrics(report, start):
    begin, end = start['FormalNS'], start['EndSendNS']
    if end <= begin:
        raise ValueError('invalid formal window')
    cohort = [s for s in report.get('Samples', []) if begin <= s['ScheduledNS'] < end]
    attempted = [s for s in cohort if s.get('SentNS', 0) > 0]
    receipts = [s for s in attempted if s.get('ReadyNS', 0) > 0]
    public = [s for s in attempted if s.get('PublicNS', 0) > 0]
    closed = [s for s in public if len(s.get('MemberNS', [])) == 4 and all(v > 0 for v in s['MemberNS'])]
    closed_ids={id(s) for s in closed}
    # ScheduledNS, FormalNS and EndSendNS all originate from start.Add(...).
    # Actual event wall timestamps may jump; reconstruct their positions using
    # the native Go time.Sub durations retained in each sample instead.
    window_ns = end - begin
    relative = {}
    diagnostic_segments = diagnostic_samples = max_discontinuity = 0
    for s in attempted:
        mono = s.get('Monotonic', {})
        lag = mono.get('ScheduleLagNS')
        if not isinstance(lag, int) or lag < 0:
            raise ValueError('attempt lacks native monotonic schedule timing')
        sent = s['ScheduledNS'] - begin + lag
        events = {}
        differences = [abs(s['SentNS'] - s['ScheduledNS'] - lag)]
        for wall_key, duration_key in (('ReadyNS', 'FastNS'), ('PublicNS', 'PublicNS')):
            if s.get(wall_key, 0) > 0:
                duration = mono.get(duration_key, 0)
                if not isinstance(duration, int) or duration <= 0:
                    raise ValueError('observed event lacks native monotonic timing')
                events[wall_key] = sent + duration
                differences.append(abs(s[wall_key] - s['SentNS'] - duration))
        members = []
        for i, wall in enumerate(s.get('MemberNS', [])):
            if wall > 0:
                durations = mono.get('MemberNS', [])
                duration = durations[i] if i < len(durations) else 0
                if not isinstance(duration, int) or duration <= 0:
                    raise ValueError('member observation lacks native monotonic timing')
                members.append(sent + duration)
                differences.append(abs(wall - s['SentNS'] - duration))
        if 'PublicNS' in events and len(members) == 4:
            events['ClosedNS'] = max(events['PublicNS'], *members)
        relative[id(s)] = events
        count = sum(d > 1_000_000 for d in differences)
        diagnostic_segments += count
        diagnostic_samples += bool(count)
        max_discontinuity = max(max_discontinuity, *differences)
    inside = [s for s in receipts if 0 <= relative[id(s)]['ReadyNS'] < window_ns]
    public_inside = [s for s in public if 0 <= relative[id(s)]['PublicNS'] < window_ns]
    def drain(samples, key):
        return max(0, max((relative[id(s)][key] for s in samples), default=0) - window_ns)/1e9
    fast = [s['Monotonic']['FastNS']/1e6 for s in receipts if s.get('Monotonic', {}).get('FastNS', 0) > 0]
    if len(fast) != len(receipts):
        raise ValueError('receipt lacks native monotonic timing')
    seconds = (end-begin)/1e9
    nominal = report.get('Options', {}).get('Rate', 0) * seconds
    return {'formal_samples': len(cohort), 'attempted': len(attempted), 'unsent': len(cohort)-len(attempted),
            'unsent_scope':'formal samples created but never sent; excludes scheduler slots without a sample',
            'nominal_formal_offered':nominal if nominal else None,
            'offered_receipt_fraction':len(receipts)/nominal if nominal else None,
            'offered_closed_fraction':len(closed)/nominal if nominal else None,
            **{k.lower()+'_including_warmup':report.get(k) for k in ('Scheduled','SkippedPacing','NoReady','PendingFull','WorkerFull')},
            'receipts': len(receipts), 'public': len(public), 'closed': len(closed),
            'attempted_without_receipt':len(attempted)-len(receipts),
            'receipts_without_closure':sum(id(s) not in closed_ids for s in receipts),
            'http_attempts':sum(s.get('Attempts',0) for s in attempted),
            'payments_with_retries':sum(s.get('Attempts',0)>1 for s in attempted),
            'requests_ended_with_error':sum(bool(s.get('Error')) for s in attempted),
            'in_window_receipts': len(inside), 'in_window_public': len(public_inside),
            'send_window_seconds': seconds,
            'receipt_drain_seconds': drain(receipts, 'ReadyNS'),
            'public_drain_seconds': drain(public, 'PublicNS'),
            'closed_drain_seconds': drain(closed, 'ClosedNS'),
            'window_timing_source': 'ScheduledNS-FormalNS+Monotonic.ScheduleLagNS+Monotonic event duration',
            'wall_clock_diagnostic_segments': diagnostic_segments,
            'wall_clock_discontinuity_samples': diagnostic_samples,
            'wall_clock_max_abs_discontinuity_ns': max_discontinuity,
            'wall_clock_diagnostic_threshold_ns': 1_000_000,
            'receipt_goodput_per_s': len(inside)/seconds, 'public_goodput_per_s': len(public_inside)/seconds,
            'completion_fraction': len(closed)/len(attempted) if attempted else None,
            'completion_denominator':'formal-cohort attempted payments (SentNS>0), after drain',
            'receipt_fraction': len(receipts)/len(attempted) if attempted else None,
            **distribution(fast, 'receipt_ms'),
            **distribution([s['CertificateBytes'] for s in receipts if s.get('CertificateBytes')], 'certificate_bytes')}


def trace_spans(events):
    definitions = {'atomic_evaluation': ('update_started', 'update_evaluated'),
                   'commit_wait': ('commit_requested', 'commit_returned'),
                   'signing': ('commit_returned', 'vote_signed'),
                   'parent_validation': ('vector_prepared', 'parents_verified')}
    active, result = {}, []
    for e in events or []:
        node, stage, instant = e.get('node'), e.get('stage'), e.get('local_ns')
        if node is None or not isinstance(instant, int):
            continue
        for name, (start, finish) in definitions.items():
            key = (node, name)
            if stage == start:
                active[key] = instant
            elif stage == finish and key in active:
                elapsed = instant - active.pop(key)
                if elapsed >= 0:
                    result.append({'node': node, 'span': name, 'duration_ns': elapsed})
    return result
