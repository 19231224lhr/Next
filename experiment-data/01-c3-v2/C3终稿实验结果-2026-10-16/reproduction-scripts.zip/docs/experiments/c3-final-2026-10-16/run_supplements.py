"""Serial predeclared independent, RTT, capacity and retained-state fault runs."""
import argparse,json,os,pathlib,subprocess,sys,time
from monitor import Monitor
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,required=True);p.add_argument('--suite',choices=['independent','rtt','capacity-faults'],required=True);p.add_argument('--repeats',type=int,default=5);p.add_argument('--start-index',type=int,default=0);p.add_argument('--directory');a=p.parse_args()
here=pathlib.Path(__file__).resolve().parent
out=a.root/(a.directory or ('formal-'+a.suite));out.mkdir(exist_ok=False)
plan=[]
for rep in range(a.repeats):
    if a.suite=='independent':cases=[dict(arm=v,workload='independent',count=100) for v in ['baseline','legacy','final']]
    elif a.suite=='rtt':cases=[dict(arm=v,workload='chain',length=100,rtt_ms=rtt) for rtt in [0,10,40] for v in ['final','fastpay-official','fastpay-tuned']]
    else:cases=[dict(arm='final',workload='mixed',rate=100,duration=30,condition=k,**v) for k,v in [('control',{}),('cal-limited',{'cal_capacity':3000}),('fuel-limited',{'fuel_capacity':2000}),('member-pause',{'fault':'member3'}),('committee-pause',{'fault':'committee3'})]]
    cases=cases[rep%len(cases):]+cases[:rep%len(cases)]
    if rep%2:cases.reverse()
    plan += [dict(repeat=rep+1,**c) for c in cases]
(out/'plan.json').write_text(json.dumps(dict(jobs=plan,cpu_affinity=sorted(os.sched_getaffinity(0)),arguments=vars(a)),default=str,indent=2)+'\n')
with (out/'status.jsonl').open('x') as status:
    for i,job in enumerate(plan):
        if i<a.start_index:continue
        name=f'{i:03d}-r{job["repeat"]}-{job["arm"]}-{job.get("condition",a.suite)}'
        if 'rtt_ms' in job:name+='-'+str(job['rtt_ms'])+'ms'
        directory=out/name;env=dict(os.environ,GOMAXPROCS='1');env.pop('FASTPAY_RUNTIME_THREADS',None)
        fp=job['arm'].startswith('fastpay')
        binary=pathlib.Path('/home/qyinf/.local/share/next-baseline-tools')/('fastpay-target' if job['arm']=='fastpay-official' else 'fastpay-runtime-sensitivity-target')/'release' if fp else a.root/('final-bin' if job['arm']=='final' else 'baseline-bin')
        if job['arm']=='fastpay-tuned':env['FASTPAY_RUNTIME_THREADS']='1'
        script='run_independent.py' if a.suite=='independent' else 'run_capacity.py' if a.suite=='capacity-faults' else 'run_extended.py'
        cmd=[sys.executable,str(here/script),'--bin',str(binary),'--run-dir',str(directory)]
        if a.suite=='independent':cmd+=['--variant',job['arm'],'--count','100']
        else:
            cmd+=['--system','fastpay' if fp else 'next','--workload',job['workload']]
            if not fp:cmd+=['--variant','final','--fixture',str(a.root/'fixtures'/('chain-final' if job['workload']=='chain' else 'mixed-final'))]
            for k in ['rtt_ms','length','rate','duration','cal_capacity','fuel_capacity','fault']:
                if k in job:cmd+=['--'+k.replace('_','-'),str(job[k])]
        print('START '+name,flush=True);start=time.time_ns()
        with (out/(name+'.log')).open('x') as log:
            process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env);monitor=Monitor(process.pid,out/(name+'-resources.csv'))
            try:code=process.wait()
            except BaseException:
                process.terminate()
                try:process.wait(timeout=55)
                except subprocess.TimeoutExpired:process.kill();process.wait()
                raise
            finally:monitor.close()
        status.write(json.dumps(dict(**job,name=name,returncode=code,start_ns=start,end_ns=time.time_ns(),command=cmd))+'\n');status.flush()
        print('END '+name+' '+str(code),flush=True)
        if code and a.suite!='capacity-faults':raise SystemExit(code)
