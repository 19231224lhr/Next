"""Run the publication-figure audits against the actual exported PDFs."""
import argparse,json,pathlib,subprocess,sys
from PIL import Image
import fitz
p=argparse.ArgumentParser();p.add_argument('--audit-dir',type=pathlib.Path,required=True);a=p.parse_args()
here=pathlib.Path(__file__).resolve().parent;figures=here/'figures';qa=figures/'qa';qa.mkdir(exist_ok=True)
def run(script,args,target):
    process=subprocess.run([sys.executable,str(a.audit_dir/script),*map(str,args)],capture_output=True,text=True,encoding='utf-8')
    target.write_text(process.stdout,encoding='utf-8')
    if process.stderr:target.with_suffix('.stderr').write_text(process.stderr,encoding='utf-8')
    return dict(exit_code=process.returncode,report=str(target.relative_to(figures)))
summary={'source':run('validate_figure.py',[here/'plot_results.py','--json'],qa/'source.json'),'figures':[]}
for pdf in sorted(figures.glob('*.pdf')):
    result=dict(name=pdf.stem)
    result['text']=run('audit_pdf_text.py',[pdf,'--min-pt','5','--json'],qa/(pdf.stem+'.text.json'))
    result['collisions']=run('audit_figure_collisions.py',[pdf,'--json','--overlay-pdf',qa/(pdf.stem+'.overlay.pdf')],qa/(pdf.stem+'.collisions.json'))
    with Image.open(pdf.with_suffix('.png')) as im:
        result['png_pixels']=im.size;result['png_dpi']=im.info.get('dpi')
        assert result['png_dpi'] and min(result['png_dpi'])>=299
    with fitz.open(pdf) as doc:
        assert len(doc)==1
        result['pdf_size_points']=tuple(doc[0].rect)[2:]
        result['embedded_fonts']=[dict(type=f[2],name=f[3],bytes=len(doc.extract_font(f[0])[3])) for f in doc[0].get_fonts()]
        assert result['embedded_fonts'] and all(f['bytes']>0 for f in result['embedded_fonts'])
    summary['figures'].append(result)
(qa/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
