"""TCP propagation proxy: a FIFO release queue per direction, no rate cap.

The asyncio loop lives on one thread so synchronous benchmark runners can use
the same adapter for HTTP, encrypted consensus P2P, and FastPay TCP traffic.
"""
import asyncio
import copy
import threading
import time


class NetworkProxy:
    def __init__(self, one_way_ms=0):
        if one_way_ms < 0:
            raise ValueError('negative propagation delay')
        self.delay = one_way_ms / 1000
        self.loop = asyncio.new_event_loop()
        self.ready = threading.Event()
        self.servers, self.tasks, self.links = [], set(), {}
        self.forbidden_ports = set()
        self.thread = threading.Thread(target=self._run, name='propagation-proxy', daemon=True)
        self.thread.start()
        if not self.ready.wait(5):
            raise TimeoutError('proxy event loop did not start')

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.ready.set()
        self.loop.run_forever()
        self.loop.close()

    def _call(self, coroutine):
        return asyncio.run_coroutine_threadsafe(coroutine, self.loop).result(timeout=15)

    def add(self, name, host, target_port):
        return self._call(self._add(name, host, target_port))

    def exclude(self, ports):
        async def exclude():
            self.forbidden_ports.update(ports)
        self._call(exclude())

    async def _add(self, name, host, target_port):
        if name in self.links:
            raise ValueError('duplicate proxy link: ' + name)
        def counters():
            return dict(bytes=0, chunks=0, hold_ns=0, max_hold_ns=0, queue_high_water=0)
        record = dict(target_host=host, target_port=target_port,
                      one_way_ms=self.delay * 1000, connections=0, errors=[],
                      client_to_target=counters(), target_to_client=counters())
        self.links[name] = record

        async def direction(reader, writer, stats):
            queue = asyncio.Queue(64)
            async def read():
                while True:
                    data = await reader.read(16384)
                    if not data:
                        await queue.put(None)
                        return
                    await queue.put((time.monotonic_ns(), data))
                    stats['queue_high_water'] = max(stats['queue_high_water'], queue.qsize())
            async def send():
                while True:
                    item = await queue.get()
                    if item is None:
                        if writer.can_write_eof():
                            writer.write_eof()
                            await writer.drain()
                        return
                    stamp, data = item
                    await asyncio.sleep(max(0, self.delay - (time.monotonic_ns() - stamp) / 1e9))
                    held = time.monotonic_ns() - stamp
                    writer.write(data)
                    await writer.drain()
                    stats['chunks'] += 1
                    stats['bytes'] += len(data)
                    stats['hold_ns'] += held
                    stats['max_hold_ns'] = max(stats['max_hold_ns'], held)
            pair = [asyncio.create_task(read()), asyncio.create_task(send())]
            try:
                await asyncio.gather(*pair)
            finally:
                for task in pair:
                    task.cancel()
                await asyncio.gather(*pair, return_exceptions=True)

        async def connected(reader, writer):
            task = asyncio.current_task()
            self.tasks.add(task)
            upstream = None
            pair = []
            try:
                remote, upstream = await asyncio.open_connection(host, target_port)
                record['connections'] += 1
                pair = [asyncio.create_task(direction(reader, upstream, record['client_to_target'])),
                        asyncio.create_task(direction(remote, writer, record['target_to_client']))]
                await asyncio.gather(*pair)
            except (ConnectionError, OSError) as exc:
                if len(record['errors']) < 100:
                    record['errors'].append(dict(unix_ns=time.time_ns(), error=repr(exc)))
            finally:
                for pending in pair:
                    pending.cancel()
                await asyncio.gather(*pair, return_exceptions=True)
                for stream in (writer, upstream):
                    if stream is not None:
                        stream.close()
                        try:
                            await stream.wait_closed()
                        except (ConnectionError, OSError):
                            pass
                self.tasks.discard(task)
        for _ in range(100):
            server = await asyncio.start_server(connected, '127.0.0.1', 0)
            if server.sockets[0].getsockname()[1] not in self.forbidden_ports:
                break
            server.close()
            await server.wait_closed()
        else:
            raise RuntimeError('cannot allocate proxy port outside real service ports')
        self.servers.append(server)
        record['listen_port'] = server.sockets[0].getsockname()[1]
        return record['listen_port']

    async def _snapshot(self):
        return copy.deepcopy(self.links)

    def snapshot(self):
        return self._call(self._snapshot())

    async def _close(self):
        for server in self.servers:
            server.close()
        await asyncio.gather(*(server.wait_closed() for server in self.servers))
        tasks = list(self.tasks)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        return copy.deepcopy(self.links)

    def close(self):
        if not self.thread.is_alive():
            return {}
        try:
            return self._call(self._close())
        finally:
            self.loop.call_soon_threadsafe(self.loop.stop)
            self.thread.join(timeout=5)
            if self.thread.is_alive():
                raise RuntimeError('proxy loop did not stop')


def self_test():
    """Small loopback echo test only; no benchmark services or builds."""
    import socket
    listener = socket.socket()
    listener.bind(('127.0.0.1', 0))
    listener.listen()
    def echo():
        connection, _ = listener.accept()
        with connection:
            while data := connection.recv(4096):
                connection.sendall(data)
        listener.close()
    thread = threading.Thread(target=echo, daemon=True)
    thread.start()
    proxy = NetworkProxy(5)
    try:
        port = proxy.add('echo', '127.0.0.1', listener.getsockname()[1])
        start = time.monotonic_ns()
        with socket.create_connection(('127.0.0.1', port), timeout=2) as connection:
            connection.sendall(b'FIFO propagation echo')
            result = b''
            while len(result) < 21:
                result += connection.recv(4096)
            assert result == b'FIFO propagation echo'
        elapsed = time.monotonic_ns() - start
        assert elapsed >= 10_000_000, elapsed
        thread.join(timeout=2)
    finally:
        stats = proxy.close()
    assert stats['echo']['client_to_target']['bytes'] == 21
    assert stats['echo']['target_to_client']['bytes'] == 21
    return dict(echo_elapsed_ns=elapsed, links=stats)


if __name__ == '__main__':
    import json
    print(json.dumps(self_test(), indent=2))
