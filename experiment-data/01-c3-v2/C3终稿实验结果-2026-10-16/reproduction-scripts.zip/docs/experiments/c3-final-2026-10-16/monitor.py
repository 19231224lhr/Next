"""Read-only Linux process-tree sampling; never used as a payment clock."""
import csv
import os
import pathlib
import threading
import time


class Monitor:
    def __init__(self, pid, path, interval=0.5):
        self.pid, self.path, self.interval = pid, pathlib.Path(path), interval
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def close(self):
        self.stop.set()
        self.thread.join()

    def run(self):
        ticks, pages = os.sysconf('SC_CLK_TCK'), os.sysconf('SC_PAGE_SIZE')
        fields = ['unix_ns', 'processes', 'cpu_seconds_sampled', 'rss_bytes',
                  'read_bytes_sampled', 'write_bytes_sampled', 'loopback_rx_bytes', 'loopback_tx_bytes']
        previous, totals = {}, [0.0, 0, 0]
        with self.path.open('w', newline='') as output:
            writer = csv.DictWriter(output, fieldnames=fields)
            writer.writeheader()
            while True:
                table = {}
                for entry in pathlib.Path('/proc').iterdir():
                    if not entry.name.isdigit():
                        continue
                    try:
                        text = (entry/'stat').read_text()
                        stat = text[text.rfind(')')+2:].split()
                        table[int(entry.name)] = (int(stat[1]), (int(stat[11])+int(stat[12]))/ticks,
                                                  int(stat[21])*pages, stat[19])
                    except (OSError, ValueError, IndexError):
                        continue
                selected = {self.pid}
                while True:
                    children = {pid for pid, row in table.items() if row[0] in selected}
                    if children <= selected:
                        break
                    selected |= children
                rss = count = 0
                for pid in selected:
                    if pid not in table:
                        continue
                    _, cpu, memory, birth = table[pid]
                    count += 1
                    rss += memory
                    try:
                        io = dict(line.split(': ') for line in pathlib.Path(f'/proc/{pid}/io').read_text().splitlines())
                        values = [cpu, int(io['read_bytes']), int(io['write_bytes'])]
                    except (OSError, ValueError, KeyError):
                        values = [cpu, 0, 0]
                    key = (pid, birth)
                    old = previous.get(key, [0, 0, 0])
                    for i in range(3):
                        totals[i] += max(0, values[i]-old[i])
                    previous[key] = values
                network = [0, 0]
                for line in pathlib.Path('/proc/net/dev').read_text().splitlines():
                    if line.strip().startswith('lo:'):
                        values = line.split(':', 1)[1].split()
                        network = [int(values[0]), int(values[8])]
                writer.writerow(dict(zip(fields, [time.time_ns(), count, *[totals[0], rss, totals[1], totals[2]], *network])))
                output.flush()
                if self.stop.wait(self.interval):
                    return
