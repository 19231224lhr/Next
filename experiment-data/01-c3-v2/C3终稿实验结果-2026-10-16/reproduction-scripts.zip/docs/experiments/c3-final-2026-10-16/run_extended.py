#!/usr/bin/env python3
"""Scoped RTT/capacity/retained-state fault adapter around the frozen runners.

Example: taskset -c 0-3 python3 run_extended.py --system next --bin BIN
 --run-dir NEW --variant final --workload chain --fixture FIXTURE --rtt-ms 10
Use --rtt-ms 0 for a proxy-path control. No direct (unproxied) RTT control is
silently substituted. Faults require Next mixed and stop exactly one process.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
import pathlib
import signal
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit

from network_proxy import NetworkProxy

HERE = pathlib.Path(__file__).resolve().parent


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace(value, mapping):
    if isinstance(value, str):
        return mapping.get(value, value)
    if isinstance(value, list):
        return [replace(item, mapping) for item in value]
    if isinstance(value, dict):
        return {key: replace(item, mapping) for key, item in value.items()}
    return value


def capacity(network, cal=None, fuel=None):
    """Rewrite finite backing and its matching balances before any process starts."""
    wanted = {}
    fuel_keys = [issuer['Funding']['Key'] for issuer in network['Direct']['C3']['Issuers']] if fuel is not None else []
    for grant in network['Genesis']['Grants']:
        key = grant['Key']
        amount = cal if key['Kind'] == 1 else fuel if key in fuel_keys else None
        if amount is None:
            continue
        if amount <= 0:
            raise ValueError('capacity must be positive')
        grant['Amount'] = amount
        token = (json.dumps(key['Account'], sort_keys=True), 1 if key['Kind'] == 1 else 2)
        wanted[token] = wanted.get(token, 0) + amount
    found = set()
    for account in network['Accounts']:
        token = (json.dumps(account['Owner'], sort_keys=True), account['Asset'])
        if token in wanted:
            account['Balance'] = wanted[token]
            found.add(token)
    if set(wanted) != found or cal is not None and not any(asset == 1 for _, asset in found) or fuel is not None and not any(asset == 2 for _, asset in found):
        raise ValueError('capacity grant lacks a matching real backing account')


def proc(pid):
    root = pathlib.Path('/proc') / str(pid)
    fields = (root/'stat').read_text().rsplit(')', 1)[1].split()
    status = dict(line.split(':', 1) for line in (root/'status').read_text().splitlines() if ':' in line)
    return dict(pid=pid, ppid=int(fields[1]), start_ticks=fields[19],
                state=fields[0], cpus=status.get('Cpus_allowed_list', '').strip(),
                command=[part.decode(errors='replace') for part in (root/'cmdline').read_bytes().split(b'\0') if part])


class Extension:
    def __init__(self, args):
        self.args, self.root = args, args.run_dir.resolve()
        self.proxy = NetworkProxy(args.rtt_ms / 2)
        self.original_popen = subprocess.Popen
        self.prepared = False
        self.lab_pid, self.target_config = None, None
        self.fault_events, self.error, self.configurations = [], None, []
        self.stop_fault = threading.Event()
        self.fault_thread, self.paused = None, None
        self.previous_stop_lab = None
        self.fault_lock = threading.Lock()

    def event(self, kind, **fields):
        with self.fault_lock:
            event = dict(kind=kind, unix_ns=time.time_ns(), monotonic_ns=time.monotonic_ns(), **fields)
            self.fault_events.append(event)
            if self.root.is_dir():
                with (self.root/'fault-events.jsonl').open('a',encoding='utf-8') as stream:
                    stream.write(json.dumps(event)+'\n')

    def snapshot_file(self, path, public=None):
        self.configurations.append(dict(path=str(path), sha256=digest(path),
                                        actual=read(path) if public is None else public))

    def prepare_next(self):
        lab_path = self.root/'lab.json'
        lab = read(lab_path)
        network_path = pathlib.Path(lab['Network'])
        network = read(network_path)
        if self.args.cal_capacity is not None or self.args.fuel_capacity is not None:
            capacity(network, self.args.cal_capacity, self.args.fuel_capacity)
        urls = set(network['CommitteeURLs']) | set(lab['Gateways'])
        for endpoints in network['Members'].values():
            urls.update(endpoints)
        urls.update(node['URL'] for node in lab['Nodes'])
        configs = [(node, pathlib.Path(node['Config']), read(pathlib.Path(node['Config']))) for node in lab['Nodes']]
        real_ports = {urlsplit(url).port for url in urls}
        real_ports.update(int(config['P2PListen'].rsplit(':',1)[1]) for node,_,config in configs if node['Binary']=='committee')
        self.proxy.exclude(real_ports)
        mapping = {}
        for url in sorted(urls):
            parsed = urlsplit(url)
            if parsed.scheme != 'http' or parsed.hostname not in ('localhost', '127.0.0.1') or parsed.port is None:
                raise ValueError('expected loopback HTTP endpoint: ' + url)
            port = self.proxy.add('next-http-' + str(parsed.port), parsed.hostname, parsed.port)
            mapping[url] = 'http://127.0.0.1:' + str(port)
        p2p = {}
        for node, _, config in configs:
            if node['Binary'] == 'committee':
                endpoint = config['P2PListen'].removeprefix('tcp://')
                host, target = endpoint.rsplit(':', 1)
                if host not in ('127.0.0.1', 'localhost'):
                    raise ValueError('non-loopback consensus endpoint')
                p2p[endpoint] = '127.0.0.1:' + str(self.proxy.add('next-p2p-' + node['Name'], host, int(target)))
        for node, path, config in configs:
            changed = replace(config, mapping)
            if node['Binary'] == 'committee':
                peers = []
                for peer in config.get('Peers', '').split(','):
                    if peer:
                        identity, endpoint = peer.rsplit('@', 1)
                        peers.append(identity + '@' + p2p[endpoint])
                changed['Peers'] = ','.join(peers)
                assert changed['P2PListen'] == config['P2PListen']
            save(path, changed)
            self.snapshot_file(path)
            target = 'org0-member3' if self.args.fault == 'member3' else 'committee3'
            if node['Name'] == target:
                self.target_config = str(path.resolve())
        save(network_path, replace(network, mapping))
        save(lab_path, replace(lab, mapping))
        self.snapshot_file(network_path)
        self.snapshot_file(lab_path)
        if self.args.fault != 'none' and self.target_config is None:
            raise ValueError('requested fault target absent from active inventory')

    def prepare_fastpay(self):
        path = self.root/'committee.json'
        rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        if len(rows) != 4:
            raise ValueError('expected four FastPay JSONL authorities')
        self.proxy.exclude(row['base_port'] for row in rows)
        for index, row in enumerate(rows):
            if row.get('network_protocol') != 'Tcp' or row.get('num_shards') != 1 or row['host'] not in ('127.0.0.1', 'localhost'):
                raise ValueError('only loopback one-shard FastPay TCP is supported')
            port = self.proxy.add('fastpay-authority-' + str(index), row['host'], row['base_port'])
            row['host'], row['base_port'] = '127.0.0.1', port
        path.write_text(''.join(json.dumps(row) + '\n' for row in rows), encoding='utf-8')
        self.configurations.append(dict(path=str(path), sha256=digest(path), actual=rows))
        for index in range(4):
            server = self.root/f'server{index}.json'
            self.snapshot_file(server, read(server)['authority'])  # Do not copy private laboratory keys.

    def popen(self, command, *args, **kwargs):
        words = [str(word) for word in command] if not isinstance(command, str) else []
        next_launch = self.args.system == 'next' and 'lab-run' in words
        fastpay_launch = self.args.system == 'fastpay' and 'run' in words and pathlib.Path(words[0]).name == 'server'
        if not self.prepared and (next_launch or fastpay_launch):
            self.prepare_next() if next_launch else self.prepare_fastpay()
            self.prepared = True
            self.write_metadata()
        child = self.original_popen(command, *args, **kwargs)
        if next_launch:
            self.lab_pid = child.pid
            self.event('lab-started', pid=child.pid)
        if self.args.fault != 'none' and 'e8' in words and '--prepare' not in words:
            if self.fault_thread is not None:
                raise RuntimeError('more than one measured mixed workload launched')
            self.fault_thread = threading.Thread(target=self.fault_worker, name='retained-state-fault', daemon=True)
            self.fault_thread.start()
        return child

    def find_target(self):
        matches = []
        for path in pathlib.Path('/proc').iterdir():
            if not path.name.isdigit():
                continue
            try:
                info = proc(int(path.name))
                if info['ppid'] == self.lab_pid and self.target_config in info['command']:
                    matches.append(info)
            except (OSError, ValueError, ProcessLookupError):
                pass
        if len(matches) != 1:
            raise RuntimeError('fault target must resolve to exactly one child: ' + repr(matches))
        return matches[0]

    def resume(self):
        if self.paused is None:
            return
        paused, self.paused = self.paused, None
        current = proc(paused['pid'])
        if current['start_ticks'] != paused['start_ticks']:
            raise RuntimeError('fault target PID was reused')
        os.kill(paused['pid'], signal.SIGCONT)
        deadline = time.monotonic() + 2
        while proc(paused['pid'])['state'] in ('T', 't'):
            if time.monotonic() > deadline:
                raise TimeoutError('fault target did not resume')
            time.sleep(.01)
        self.event('continued', target=proc(paused['pid']))

    def fault_worker(self):
        try:
            marker = self.root/'reports'/'e8-start.json'
            deadline = time.monotonic() + 120
            while not self.stop_fault.is_set():
                try:
                    window = read(marker)
                    when = window['FormalNS']/1e9 + self.args.fault_after
                    if when + self.args.fault_seconds > window['EndSendNS']/1e9:
                        raise ValueError('fault interval must fit within the formal send window')
                    break
                except (FileNotFoundError, json.JSONDecodeError):
                    if time.monotonic() > deadline:
                        raise TimeoutError('formal window marker absent')
                    self.stop_fault.wait(.02)
            else:
                return
            self.event('scheduled', formal_ns=window['FormalNS'], end_send_ns=window['EndSendNS'], stop_unix_ns=int(when*1e9))
            if self.stop_fault.wait(max(0, when-time.time())):
                return
            if time.time()+self.args.fault_seconds > window['EndSendNS']/1e9:
                raise RuntimeError('actual fault would extend beyond the formal send window')
            target = self.find_target()
            self.paused = target
            os.kill(target['pid'], signal.SIGSTOP)
            deadline = time.monotonic()+2
            while proc(target['pid'])['state'] not in ('T', 't'):
                if time.monotonic()>deadline:
                    raise TimeoutError('SIGSTOP state not observed')
                time.sleep(.01)
            self.event('stopped', target=proc(target['pid']))
            self.stop_fault.wait(self.args.fault_seconds)
        except Exception as exc:
            self.error = repr(exc)
            self.event('fault-error', error=self.error)
        finally:
            try:
                self.resume()
            except Exception as exc:
                self.error = repr(exc)
                self.event('resume-error', error=self.error)

    def restore_fault(self):
        self.stop_fault.set()
        if self.fault_thread is not None:
            self.fault_thread.join(timeout=self.args.fault_seconds+5)
            if self.fault_thread.is_alive():
                raise RuntimeError('fault worker did not finish')
        self.resume()

    def write_metadata(self, links=None):
        if not self.root.exists():
            return
        save(self.root/'extended.json', dict(system=self.args.system, rtt_ms=self.args.rtt_ms,
            one_way_ms=self.args.rtt_ms/2, bandwidth_limit=None,
            propagation_model='bounded FIFO per TCP direction, release at read-arrival + one-way delay',
            cpu_affinity=sorted(os.sched_getaffinity(0)), gomaxprocs=os.environ.get('GOMAXPROCS'),
            arguments={key:str(value) if isinstance(value,pathlib.Path) else value for key,value in vars(self.args).items()},
            harness_sha256={name:digest(HERE/name) for name in ('run_extended.py','network_proxy.py')},
            actual_configs=self.configurations, links=links if links is not None else self.proxy.snapshot(),
            fault_events=self.fault_events, extension_error=self.error))

    def __enter__(self):
        subprocess.Popen = self.popen
        return self

    def __exit__(self, kind, error, traceback):
        subprocess.Popen = self.original_popen
        try:
            self.restore_fault()
        finally:
            links = self.proxy.close()
            if error is not None:
                self.error = repr(error)
            self.write_metadata(links)
        return False


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def run(args):
    if sys.platform != 'linux':
        raise RuntimeError('run on Linux ext4 with taskset -c 0-3')
    if not os.sched_getaffinity(0) <= {0,1,2,3}:
        raise ValueError('inherit the controlled CPU set with taskset -c 0-3')
    os.environ['GOMAXPROCS'] = '1'
    if args.rate is None:
        args.rate = 100 if args.system == 'next' else 0
    if any(not math.isfinite(number) for number in (args.rtt_ms,args.fault_seconds,args.fault_after,args.rate)) or args.rtt_ms < 0 or args.fault_seconds <= 0 or args.fault_after < 0:
        raise ValueError('invalid propagation/fault duration')
    if args.system == 'next':
        if args.rate <= 0 or args.rate != int(args.rate):
            raise ValueError('Next rate must be a positive integer')
        args.rate = int(args.rate)
    if args.fault != 'none' and (args.system != 'next' or args.workload != 'mixed'):
        raise ValueError('single member/committee fault requires Next mixed workload')
    if args.system == 'fastpay' and (args.cal_capacity is not None or args.fuel_capacity is not None):
        raise ValueError('capacity controls are Next grant controls')
    if args.system == 'fastpay' and (args.storage != 'memory' or args.fixture is not None):
        raise ValueError('FastPay uses memory storage and --seed-config, not --fixture')
    core = module('extended_next', HERE/'run_final.py') if args.system == 'next' else module('extended_fastpay', HERE.parent/'baseline-design-2026-10-13'/'run_fastpay.py')
    with Extension(args) as extension:
        if args.system == 'next':
            original = core.base.stop_lab
            def stop_lab(process):
                try:
                    extension.restore_fault()  # Resume before graceful cleanup.
                except BaseException as exc:
                    extension.error = repr(exc)
                    extension.event('cleanup-resume-error', error=repr(exc))
                finally:
                    original(process)
            core.base.stop_lab = stop_lab
            try:
                result = core.run(args)
            finally:
                core.base.stop_lab = original
        else:
            if args.workload == 'mixed':
                args.workload = 'independent'
            result = core.run(args)
        if not extension.prepared:
            raise RuntimeError('runner launch hook did not apply configuration')
        if extension.error:
            raise RuntimeError(extension.error)
        if args.fault != 'none' and not any(event['kind']=='stopped' for event in extension.fault_events):
            raise RuntimeError('requested fault was not executed in the formal window')
        return result


def self_test():
    """Only tiny synthetic configuration checks and a 21-byte echo exchange."""
    import copy
    import tempfile
    from network_proxy import self_test as echo_test
    fuel_key = dict(Kind=2, Account='fuel-pool', Version=1)
    network = dict(Members={'issuer':['http://127.0.0.1:41010']},
        CommitteeURLs=['http://127.0.0.1:41001','http://127.0.0.1:41002'],
        Direct={'C3':{'Issuers':[{'Funding':{'Key':fuel_key}}]}},
        Genesis={'Grants':[{'Key':dict(Kind=1,Account='issuer',Version=1),'Amount':100},
                           {'Key':fuel_key,'Amount':100},
                           {'Key':dict(Kind=3,Account='issuer',Version=1),'Amount':77}]},
        Accounts=[dict(Owner='issuer',Asset=1,Balance=100),dict(Owner='fuel-pool',Asset=2,Balance=100),
                  dict(Owner='other',Asset=2,Balance=500)])
    changed = copy.deepcopy(network)
    capacity(changed, 20, 30)
    assert [g['Amount'] for g in changed['Genesis']['Grants']] == [20,30,77]
    assert [a['Balance'] for a in changed['Accounts']] == [20,30,500]
    with tempfile.TemporaryDirectory() as temporary:
        root = pathlib.Path(temporary)
        save(root/'network.json', network)
        nodes = []
        for i in range(2):
            path = root/f'committee{i}.json'
            save(path, dict(Listen=f'127.0.0.1:{41001+i}',P2PListen=f'tcp://127.0.0.1:{41050+i}',
                            Peers=f'peer@127.0.0.1:{41051-i}'))
            nodes.append(dict(Name=f'committee{i}',Binary='committee',Config=str(path),URL=f'http://127.0.0.1:{41001+i}'))
        save(root/'lab.json', dict(Network=str(root/'network.json'),Nodes=nodes,Gateways=['http://127.0.0.1:41200']))
        args = argparse.Namespace(system='next',run_dir=root,rtt_ms=0,cal_capacity=20,fuel_capacity=30,fault='none')
        extension = Extension(args)
        try:
            extension.prepare_next()
            assert read(root/'network.json')['Members'] != network['Members']
            assert read(root/'lab.json')['Nodes'][0]['URL'] != nodes[0]['URL']
            config = read(root/'committee0.json')
            assert config['Listen']=='127.0.0.1:41001' and config['P2PListen']=='tcp://127.0.0.1:41050'
            assert config['Peers'] != 'peer@127.0.0.1:41051' and isinstance(config['Peers'],str)
            next_links = len(extension.proxy.snapshot())
        finally:
            extension.proxy.close()
        fast = root/'fastpay'
        fast.mkdir()
        rows = [dict(network_protocol='Tcp',address=f'authority-{i}',host='127.0.0.1',base_port=43001+i,num_shards=1) for i in range(4)]
        (fast/'committee.json').write_text(''.join(json.dumps(row)+'\n' for row in rows))
        for i,row in enumerate(rows):
            save(fast/f'server{i}.json',dict(authority=row,key='PRIVATE_TEST_DO_NOT_COPY'))
        before = [digest(fast/f'server{i}.json') for i in range(4)]
        args.system,args.run_dir='fastpay',fast
        extension = Extension(args)
        try:
            extension.prepare_fastpay()
            actual = [json.loads(line) for line in (fast/'committee.json').read_text().splitlines()]
            assert all(a['address']==b['address'] and a['base_port']!=b['base_port'] for a,b in zip(actual,rows))
            assert before == [digest(fast/f'server{i}.json') for i in range(4)]
            assert 'PRIVATE_TEST_DO_NOT_COPY' not in json.dumps(extension.configurations)
        finally:
            extension.proxy.close()
        fault_check = 'Linux-only'
        if sys.platform == 'linux':
            args.system,args.run_dir,args.fault='next',root,'member3'
            args.fault_after,args.fault_seconds=0,.05
            now=time.time_ns()
            save(root/'reports'/'e8-start.json',dict(FormalNS=now+100_000_000,EndSendNS=now+2_000_000_000))
            extension=Extension(args)
            extension.lab_pid=os.getpid()
            extension.target_config=str(root/'idle-fault-target')
            child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(3)',extension.target_config])
            try:
                extension.fault_worker()
                assert extension.error is None, extension.error
                kinds=[event['kind'] for event in extension.fault_events]
                assert kinds==['scheduled','stopped','continued'],kinds
                assert proc(child.pid)['state'] not in ('T','t')
                fault_check='one idle child SIGSTOP/proc/CONT passed'
            finally:
                extension.restore_fault()
                child.terminate()
                child.wait(timeout=2)
                extension.proxy.close()
    return dict(configuration_checks='passed',next_links=next_links,fastpay_links=4,fault_check=fault_check,echo=echo_test())


def main():
    if sys.argv[1:] == ['--self-test']:
        print(json.dumps(self_test(), indent=2))
        return
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--system', choices=('next','fastpay'), required=True)
    parser.add_argument('--bin', type=pathlib.Path, required=True)
    parser.add_argument('--run-dir', type=pathlib.Path, required=True)
    parser.add_argument('--variant', choices=('baseline','c3','final'), default='final')
    parser.add_argument('--workload', choices=('chain','mixed','independent'), default='chain')
    parser.add_argument('--rtt-ms', type=float, default=0)
    parser.add_argument('--fault', choices=('none','member3','committee3'), default='none')
    parser.add_argument('--fault-after', type=float, default=2)
    parser.add_argument('--fault-seconds', type=float, default=5)
    parser.add_argument('--cal-capacity', type=int)
    parser.add_argument('--fuel-capacity', type=int)
    parser.add_argument('--storage', choices=('memory','sync'), default='memory')
    parser.add_argument('--gateway-mode', choices=('plain','compact','continuation'), default='compact')
    parser.add_argument('--base-fee', type=int, default=0)
    parser.add_argument('--length', type=int, default=100)
    parser.add_argument('--count', type=int, default=100)
    parser.add_argument('--rate', type=float, help='Next default100; FastPay default0 (unpaced)')
    parser.add_argument('--duration', type=int, default=30)
    parser.add_argument('--fixture', type=pathlib.Path)
    parser.add_argument('--seed-config', type=pathlib.Path)
    parser.add_argument('--client-mode', choices=('normal','receiver-confirmed'), default='receiver-confirmed')
    args = parser.parse_args()
    args.trace, args.sources, args.block_bytes, args.reserved_bps = False, 4, 32768, 2500
    args.case, args.delay_ms, args.save_fixture, args.protocol = 'source-first', 0, None, 'Tcp'
    if args.system == 'next' and args.workload == 'independent':
        parser.error('Next independent workload is not provided by the frozen run_final runner')
    def interrupted(signum, _frame):
        raise InterruptedError(f'extended runner interrupted: {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    try:
        result = run(args)
        save(args.run_dir/'extended-result.json', result)
        print(json.dumps(result))
        if result.get('native_exit_code', 0):
            raise SystemExit(result['native_exit_code'])
    except Exception as exc:
        if args.run_dir.exists():
            save(args.run_dir/'extended-error.json', dict(error=repr(exc)))
        raise


if __name__ == '__main__':
    main()
