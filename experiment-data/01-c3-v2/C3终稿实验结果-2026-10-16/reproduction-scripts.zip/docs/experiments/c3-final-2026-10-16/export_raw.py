"""Export measured reports/logs/configurations without laboratory private keys."""
import argparse,hashlib,json,pathlib,zipfile
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
files=[]
for suite in a.root.iterdir():
    if suite.is_file() and suite.suffix in ('.json','.jsonl','.log','.txt'):files.append(suite)
    elif suite.is_dir() and suite.name.startswith(('formal-','diagnostic-','pilot-','pilot2-')):
        for f in suite.rglob('*'):
            if not f.is_file() or f.is_symlink():continue
            rel=f.relative_to(suite);parts=rel.parts
            if any(x in ('keys','launch-bin','independent-launch-bin') for x in parts):continue
            if f.suffix not in ('.json','.jsonl','.csv','.log','.txt','.toml','.stderr'):continue
            if len(parts)==1 or 'reports' in parts or 'logs' in parts or 'adapter-logs' in parts or rel.as_posix().endswith('config/network.json') or (len(parts)==2 and (f.suffix in ('.log','.stderr') or parts[-1] in ('manifest.json','result.json','extended.json','extended-result.json','extended-error.json','independent-result.json','independent-manifest.json','runner-error.json','lab.json','committee.json','native-client.json','fault-events.jsonl','roles.json','initial_accounts.txt'))):
                if (f.name.startswith('server') and f.suffix=='.json') or f.name in ('wallet.json','accounts.json','priv_validator_key.json','node_key.json'):continue
                files.append(f)
a.out.parent.mkdir(parents=True,exist_ok=True);manifest=[]
with zipfile.ZipFile(a.out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in sorted(set(files)):
        data=f.read_bytes();name=f.relative_to(a.root).as_posix();manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()));z.writestr(name,data)
    z.writestr('RAW-MANIFEST.json',json.dumps(dict(source_root=str(a.root),files=manifest,excluded='Private lab keys, wallet databases, executable copies, server secret configurations; original full runs remain on ext4.'),indent=2))
print(json.dumps(dict(files=len(manifest),bytes=a.out.stat().st_size,path=str(a.out))))
