"""Small adapter checks; no services, network workloads, or builds."""
import copy
import unittest
from run_final import chain_result


def fixture():
    hops=[]
    for i in range(2):
        hops.append(dict(Hop=i+1,Tx=[10+i]*32,Fact=[20+i]*32,Input=[i+1]*32,Output=[i+2]*32,
            CertificateInput=i>0,OutputData=dict(Asset=1,Amount=100),FastMS=2,
            SentOffsetMS=i*3,ReadyOffsetMS=i*3+2,FinalOffsetMS=i+8,MemberOffsetMS=i+10,
            SentUnixNS=(i*3+1)*1_000_000,ReadyUnixNS=(i*3+3)*1_000_000,
            FinalUnixNS=(i+9)*1_000_000,MemberClosedUnixNS=(i+11)*1_000_000))
    return dict(Requested=2,Hops=hops,FastChainMS=5,PublicChainMS=9,ClosedChainMS=11)


class MonotonicChainTests(unittest.TestCase):
    def test_wall_rollback_is_recorded_without_changing_raw_evidence(self):
        report=fixture();report['Hops'][0]['SentUnixNS']=10_000_000
        raw=copy.deepcopy(report);result=chain_result(report,2)
        self.assertEqual(result['closure_status'],'complete')
        self.assertEqual(result['samples_ms'],[2,2]);self.assertTrue(result['wall_clock_discontinuities'])
        self.assertEqual(report,raw)

    def test_bad_monotonic_or_safety_fields_still_reject(self):
        for key,value in [('FastMS',3),('ReadyOffsetMS',float('nan')),('FinalOffsetMS',1),('MemberOffsetMS',0),('Input',[8]*32),('OutputData',dict(Asset=1,Amount=99)),('Fact',[0]*32)]:
            with self.subTest(key=key):
                report=fixture();report['Hops'][1][key]=value
                with self.assertRaises(ValueError):chain_result(report,2)

    def test_incomplete_closure_is_not_promoted(self):
        report=fixture();report['Error']='member observation failed'
        self.assertEqual(chain_result(report,2)['closure_status'],'incomplete')


if __name__=='__main__':
    unittest.main()
