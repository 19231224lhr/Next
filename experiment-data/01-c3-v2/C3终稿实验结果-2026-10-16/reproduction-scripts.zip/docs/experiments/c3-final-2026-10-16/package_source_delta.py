"""Package only changes between the two measured source snapshots."""
import difflib,hashlib,json,pathlib,zipfile
here=pathlib.Path(__file__).resolve().parent
old=json.loads((here/'baseline-manifest.json').read_text())
new=json.loads((here/'final-manifest.json').read_text())
before,after=pathlib.Path(old['source_snapshot']),pathlib.Path(new['source_snapshot'])
left={r['path']:r for r in old['files']};right={r['path']:r for r in new['files']}
changes=[];patch=[]
with zipfile.ZipFile(here/'source-delta.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in sorted(left.keys()|right.keys()):
        b=(before/name).read_bytes() if name in left else b''
        a=(after/name).read_bytes() if name in right else b''
        if b==a:continue
        changes.append(dict(path=name,old_sha256=hashlib.sha256(b).hexdigest() if b else None,new_sha256=hashlib.sha256(a).hexdigest() if a else None))
        patch.extend(difflib.unified_diff(b.decode('utf-8').splitlines(True),a.decode('utf-8').splitlines(True),fromfile='a/'+name if b else '/dev/null',tofile='b/'+name if a else '/dev/null'))
        if a:z.writestr('final/'+name,a)
    z.writestr('source-delta.patch',''.join(patch))
    z.writestr('CHANGES.json',json.dumps(dict(baseline=str(before),final=str(after),files=changes),indent=2))
(here/'source-delta.patch').write_text(''.join(patch),encoding='utf-8',newline='')
(here/'source-changes.json').write_text(json.dumps(changes,indent=2)+'\n')
print(json.dumps(dict(changed_files=len(changes),archive=str(here/'source-delta.zip'))))
