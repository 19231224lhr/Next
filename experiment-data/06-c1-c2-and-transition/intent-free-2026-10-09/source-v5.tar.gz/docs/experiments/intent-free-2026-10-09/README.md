# Current protocol v5 experiments

Fresh source snapshot after removing payment Intent and enforcing immutable
wallet-to-organization bindings from genesis. The Git HEAD is a reference;
the source file manifest and archive SHA-256 identify the actual working tree.
Legacy `chain-v4`, `bench-v4`, `demo-v4`, and `budget-v4` command names remain
CLI aliases; their transactions in this snapshot use wire/version 5.

Major runs: single-organization and cross-organization 100-payment F/W/M chains
(three repeats each); N/R/C/P mixed workload (three repeats each); finite-capital
matrix (four cells, three repeats). Each experiment starts from fresh genesis
and is run serially on the Mac Studio. No runtime private keys are exported.

Results and checks will be recorded after execution. Earlier-version results
are retained in their original directories as historical evidence.
