#!/usr/bin/env python3
"""Write the Chinese results report from checked, complete measured CSVs."""
import argparse
import csv
import json
import pathlib
import statistics


def read(root, name):
    with (root/(name+'.csv')).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def spread(values, digits=2):
    return f'{statistics.median(values):.{digits}f} [{min(values):.{digits}f}, {max(values):.{digits}f}]'


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv', type=pathlib.Path, required=True)
    p.add_argument('--out', type=pathlib.Path, required=True)
    a=p.parse_args()
    checked=json.loads((a.csv/'evidence-check.json').read_text())
    assert checked['status']=='PASS'
    perf=read(a.csv,'performance_runs'); fees=read(a.csv,'fee_runs'); summaries=read(a.csv,'summary')
    lines=['# 新 C3：实现与真实服务实验结果', '',
           '新 C3 已实现并接入现有付款路径。53 次正式服务运行全部完成，包括 27 次费用运行和 26 次性能/诊断运行；费用实验共 369 对来源—后继付款。完整 Go 回归测试及 5 项 Python 统计/夹具测试通过。', '',
           '## 环境与版本', '',
           '- 旧版：`909ac2c`；新 C3 测量代码：`a9d943e6ae04b458069cd46806043c4142a03a6d`。四个服务/客户端二进制均从相应源码重新构建，SHA-256 见 `current-build.json`、`baseline-binaries.json` 和各轮 manifest。',
           '- AMD Ryzen AI 9 HX 370，Windows 11 / Ubuntu WSL2（Linux 6.6.87.2）。所有服务与客户端共享 CPU 0–3，`GOMAXPROCS=4`；数据位于 Linux ext4。Go 1.27.1、CometBFT 0.38.26，`comet_v3` 构建。',
           '- 费用实验：两组织各四成员、两网关、四委员会节点。性能实验：四成员、一网关、四委员会节点。两性能版本均使用内存服务存储和相同的钱包 NoSync 配置，自动补交开启；因此这些数值对应本机原型性能。',
           '- 费用实验主动控制来源提交并关闭自动来源补交，其他签名、共识、账本执行、赔付和偿还均由真实服务完成。报价 q=10 FUEL，单输出预算 M=6，固定报酬 2，open/close/comp/repay 各 1；这是本实验费率配置。',
           '- 下表的区间均为重复运行的最小—最大值；先计算每轮指标，再取跨轮中位数。未将同轮数千笔付款当作数千次独立实验。', '',
           '## 实验一：执行顺序与费用确定性', '',
           '三种顺序各运行三次。每一轮在各顺序之间复用完全相同的已签名来源及后继请求、初始资金和报价；CSV 核对了交易标识一致。以下为每笔来源付款的最终实测值，三轮一致。', '',
           '| 执行路径 | 用户净支出 | 组织支出 | Burned | Rewards | Held | Released |',
           '|---|---:|---:|---:|---:|---:|---:|']
    for case,label in [('source-first','来源先执行'),('child-first','后继先执行、来源履行'),('compensated','赔付后来源偿还')]:
        group=[r for r in fees if r['case']==case]
        fields=['source_user_fee','source_burned','source_rewards','source_released']
        assert len(group)==3 and all(len({r[k] for r in group})==1 for k in fields)
        r=group[0]; burn=int(r['source_burned']); rewards=int(r['source_rewards'])
        lines.append(f"| {label} | {r['source_user_fee']} | {burn+rewards} | {burn} | {rewards} | 0 | {r['source_released']} |")
    lines += ['', '赔付完成而来源尚未执行的中间快照为：组织已支出 5、仍保留 1、释放 0，来源用户报价尚未收取。来源随后执行，用户才支付 10，剩余 1 用于偿还处理。后继付款在三条路径中始终只支付自己的 10，其组织支出始终为 2。找零与退款是否存在均从钱包的已验证账本状态检查。', '',
              '## 实验二：来源延迟与组织费用', '',
              '每档三轮，每轮 20 对付款；来源延迟从取得来源凭证计至实际提交。最初测量 0、100、500、1500、4000 ms；这些运行未发生赔付，随后增加 12000 ms 条件，保留全部原始条件。12 秒档复用相应轮的输入，在全新服务状态中运行。', '',
              '| 来源延迟 ms | 来源先行笔数 | 乱序后履行笔数 | 赔付后偿还笔数 | 每笔来源组织支出 FUEL | 公共 Held 峰值 FUEL |',
              '|---:|---:|---:|---:|---:|---:|']
    for delay in sorted({float(r['delay_ms']) for r in fees if r['case']=='delay'}):
        group=[r for r in fees if r['case']=='delay' and float(r['delay_ms'])==delay]
        assert len(group)==3
        values=[spread([float(r[k]) for r in group],0) for k in ('source_first','child_first_fulfilled','compensated_repaid')]
        cost=spread([(int(r['source_burned'])+int(r['source_rewards']))/20 for r in group])
        peak=spread([float(r['sampled_public_held_peak']) for r in group],0)
        lines.append(f"| {delay:g} | {' | '.join(values)} | {cost} | {peak} |")
    lines += ['', '所有延迟档的付款和来源清偿完成率均为 100%。每轮来源组织收入均为 200 FUEL；来源用户合计支付 200，后继用户合计支付 200。每轮来源及后继的委员会报酬分别固定为 40；额外费用进入来源侧 Burned，后继侧 Burned 为 0。来源组织的收入减协议支出随异常增加而减少，未将这一差额称为扣除运维后的利润。', '',
              '预算峰值来自约 50 ms 间隔的查询，是采样下界；两池查询不是跨池原子快照。短暂托管可能在同一块内建立并释放，所以采样峰值 0 不表示没有预留。成员签名前的 FUEL 预留另见 `budget_samples.csv`；已支出部分继续计入成员累计使用，不与公共 Held 重复相加。', '',
              '## 实验三：实际性能开销', '',
              '连续付款和混合负载各五组新旧配对运行，交替先跑旧版或新版。连续链包含 100 笔依赖付款；混合负载为 16 条链、32 个钱包、100 笔/秒、正式窗口 30 秒，并保留排空阶段。主测量关闭诊断追踪。', '',
              '| 指标 | 旧版中位数 [范围] | 新 C3 中位数 [范围] |',
              '|---|---:|---:|']
    for workload,metric,label in [('chain','receipt_ms_p50','连续链单笔收款 P50 / ms'),('chain','receipt_ms_p95','连续链单笔收款 P95 / ms'),('chain','chain_total_ms','100 笔链完成时间 / ms'),('chain','certificate_bytes_p50','连续链 TXCer / byte'),('mixed','receipt_ms_p50','混合负载收款 P50 / ms'),('mixed','receipt_ms_p95','混合负载收款 P95 / ms'),('mixed','receipt_goodput_per_s','窗口内收款吞吐 / 笔每秒'),('mixed','public_goodput_per_s','窗口内公开执行吞吐 / 笔每秒')]:
        cells=[]
        for variant in ('baseline','c3'):
            vals=[float(r[metric]) for r in perf if r['workload']==workload and r['variant']==variant and r['trace']=='False']
            assert len(vals)==5
            cells.append(spread(vals,0 if 'bytes' in metric else 2))
        lines.append(f"| {label} | {' | '.join(cells)} |")
    lines += ['', '配对的整链时间相对变化（每轮新/旧 − 1，而非先合并付款样本）：']
    ratios=[]
    for repeat in range(1,6):
        selected={r['variant']:float(r['chain_total_ms']) for r in perf if r['run'].startswith(f'chain-r{repeat}-')}
        ratios.append(100*(selected['c3']/selected['baseline']-1))
    lines += [f'中位数 {spread(ratios)}%。新费用承诺增加 517 字节；C1 认证轮次不变。', '',
              '| 混合负载完成情况 | 旧版（五轮合计） | 新 C3（五轮合计） |', '|---|---:|---:|']
    groups={v:[r for r in perf if r['workload']=='mixed' and r['variant']==v] for v in ('baseline','c3')}
    for field,label in [('nominal_formal_offered','计划发送'),('attempted','实际发送'),('receipts','收到凭证'),('public','公开执行完成'),('closed','成员及账本完成')]:
        vals=[sum(float(r[field]) for r in groups[v]) for v in ('baseline','c3')]
        lines.append(f'| {label} | {vals[0]:g} | {vals[1]:g} |')
    completion=[]
    for v in ('baseline','c3'):
        complete=sum(float(r['closed']) for r in groups[v])
        sent=sum(float(r['attempted']) for r in groups[v])
        offered=sum(float(r['nominal_formal_offered']) for r in groups[v])
        completion.append(f'{complete/sent*100:.2f}% / {complete/offered*100:.2f}%')
    lines += ['', f'已发送付款完成率 / 计划负载完成率：旧版 {completion[0]}，新 C3 {completion[1]}。窗口内吞吐不包括窗口结束后的排空完成量。这是固定 100 笔/秒负载对照，没有据此宣称系统饱和吞吐量。', '',
              '另做三组开启同样追踪的诊断运行，以下是每轮路径 P50 的跨轮统计。', '',
              '| 诊断路径 / µs | 旧版中位数 [范围] | 新 C3 中位数 [范围] |', '|---|---:|---:|']
    labels={'atomic_evaluation_us_p50':'成员原子检查与预留','commit_wait_us_p50':'成员等待提交','signing_us_p50':'成员签名','parent_validation_us_p50':'来源验证','committed_execute_wall_us_p50':'委员会完整执行路径'}
    for metric,label in labels.items():
        cells=[]
        for variant in ('baseline','c3'):
            s=next(r for r in summaries if r['workload']=='diagnostic' and r['variant']==variant and r['metric']==metric)
            cells.append(f"{float(s['median']):.2f} [{float(s['min']):.2f}, {float(s['max']):.2f}]")
        lines.append(f"| {label} | {' | '.join(cells)} |")
    lines += ['', '诊断记录的是完整路径：原子检查包含预留及其他验证，委员会执行包含交易和费用状态转换；没有将其误称为单独一条 FUEL 指令的耗时。成员跨度使用同一节点的本地计时，委员会跨度仅纳入已提交执行记录。', '',
              '## 功能验证与交付', '',
              '- `final-go-tests.txt`：完整 `go test -count=1 -tags=comet_v3 ./...` 通过。F1–F4 测试及代码入口见 `IMPLEMENTATION.zh-CN.md`，未公开凭证、并发预留、多输出、跨组织归责、重复阶段和恢复均有自动化覆盖。',
              '- 真实服务的重复来源提交结果及 HTTP 响应逐笔保存在 `fee_pairs.csv` 与原始 JSON。HTTP 拒绝不能充当“重复交易已入块”的证据；公共事件去重另由状态机与集成测试验证。原历史修复在赔付场景继续完成，其观察快照可能与偿还同块，不把它描述成隔离的修复开销实验。',
              '- `csv/`：逐轮、逐付款、逐阶段、采样预算、重试及诊断 CSV；`figures/`：三张 PDF/SVG 矢量图及 PNG 预览；`native-evidence.tar.gz`：原生报告、配置、服务日志与准备好的实验夹具。',
              '- 运行与重新统计命令见 `README.md`。未将预跑混入正式统计；预跑另行归档。新增性质的完整形式化证明仍需按 `proof-obligations.md` 写出，当前交付的是实现、测试与实验事实。', '']
    a.out.write_text('\n'.join(lines), encoding='utf-8')


if __name__=='__main__':
    main()
