package wallet

import (
	"bytes"
	"container/list"
	"encoding/json"
	"errors"
	"sync"
	"utxo/internal/state"
	"utxo/protocol"
)

const directCoinCacheEntries = 256
const directCoinCacheBytes = 4 << 20

type directCoinStatus struct {
	Final     protocol.Hash
	Recovered bool
}
type directCoinStatusEntry struct {
	key    string
	raw    []byte
	status directCoinStatus
}

// The cache carries no authorization. A hit requires reading the current store
// value and comparing every byte with a previously fully decoded record.
type directCoinStatusCache struct {
	mu      sync.Mutex
	entries map[string]*list.Element
	order   list.List
	bytes   int
}

func (c *directCoinStatusCache) lookup(key, raw []byte) (directCoinStatus, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if e := c.entries[string(key)]; e != nil {
		item := e.Value.(directCoinStatusEntry)
		if bytes.Equal(item.raw, raw) {
			c.order.MoveToFront(e)
			return item.status, true
		}
	}
	return directCoinStatus{}, false
}
func (c *directCoinStatusCache) remember(key, raw []byte, status directCoinStatus) {
	if len(raw) > directCoinCacheBytes || len(key) > directCoinCacheBytes-len(raw) {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.entries == nil {
		c.entries = make(map[string]*list.Element)
	}
	k := string(key)
	remove := func(e *list.Element) {
		item := e.Value.(directCoinStatusEntry)
		delete(c.entries, item.key)
		c.bytes -= len(item.key) + len(item.raw)
		c.order.Remove(e)
	}
	if e := c.entries[k]; e != nil {
		remove(e)
	}
	size := len(k) + len(raw)
	for len(c.entries) >= directCoinCacheEntries || c.bytes+size > directCoinCacheBytes {
		remove(c.order.Back())
	}
	c.entries[k] = c.order.PushFront(directCoinStatusEntry{key: k, raw: bytes.Clone(raw), status: status})
	c.bytes += size
}

func (w *Wallet) loadDirectCoin(v state.ReadView, key []byte) (DirectCoin, bool, error) {
	var coin DirectCoin
	raw, err := v.Get(key)
	if errors.Is(err, state.ErrNotFound) {
		return coin, false, nil
	}
	if err != nil {
		return coin, false, err
	}
	if err = json.Unmarshal(raw, &coin); err != nil {
		return coin, false, err
	}
	w.coinStatus.remember(key, raw, directCoinStatus{Final: coin.Final, Recovered: coin.Recovered})
	return coin, true, nil
}

// ReadDirectCoin returns an independently decoded coin. Its status can be reused
// by the following save only if that save reads exactly the same store bytes.
func (w *Wallet) ReadDirectCoin(id protocol.OutputID, instance uint8) (DirectCoin, bool, error) {
	var coin DirectCoin
	var found bool
	err := w.db.View(func(v state.ReadView) error {
		var err error
		coin, found, err = w.loadDirectCoin(v, DirectCoinKey(id, instance))
		return err
	})
	return coin, found, err
}

func (w *Wallet) loadDirectCoinStatus(v state.ReadView, key []byte) (directCoinStatus, bool, error) {
	raw, err := v.Get(key)
	if errors.Is(err, state.ErrNotFound) {
		return directCoinStatus{}, false, nil
	}
	if err != nil {
		return directCoinStatus{}, false, err
	}
	if status, ok := w.coinStatus.lookup(key, raw); ok {
		return status, true, nil
	}
	// Decode the entire schema: projecting only Final/Recovered would accept
	// invalid known fields such as a malformed certificate or output.
	var coin DirectCoin
	if err = json.Unmarshal(raw, &coin); err != nil {
		return directCoinStatus{}, false, err
	}
	status := directCoinStatus{Final: coin.Final, Recovered: coin.Recovered}
	w.coinStatus.remember(key, raw, status)
	return status, true, nil
}
